package wjhk.jupload2.gui.filepanel.treeview;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import wjhk.jupload2.exception.JUploadExceptionStopAddingFiles;
import wjhk.jupload2.gui.filepanel.FilePanelTableImp;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * From Jörn sample, the main modifications are:
 * <UL>
 * <LI>Add of the getRoot and setRoot methods</LI>
 * <LI>Capability to remove an item</LI>
 * <LI>Transformation in a generic type</LI>
 * <LI>Add of the reload method, to help refreshing the display.</LI>
 * <LI>Add of the {@link #getColumnSizePercentage(int)} method, to allow the resizing of the column, along with the
 * table resizing (see {@link FilePanelTableImp#componentResized(java.awt.event.ComponentEvent)}
 * <UL>
 * <BR/>
 * First, the interface is TreeModel through the interface MyTreeTableModel expanded. This extension creates the
 * possibility that a node (Node) multiple columns (Columns) can have. <BR/>
 * <BR/>
 * This class can not be generic, as TreeModel is not generic
 * 
 * @author Jörn Hameister
 */
public interface MyTreeTableModel<T extends MyTreeNode> extends TreeModel {

    /**
     * Get the visible root of the JTree view.
     * 
     * @param root
     */
    public T getRoot();

    /**
     * Set the visible root of the JTree view.
     * 
     * @param root
     */
    public void setRoot(T root);

    /**
     * Removes an item from the TreeView. This method just removed the given node. Of course, it detaches all
     * descendants of this node, if any. <BR/>
     * There is no impact on the parent, out of the 'detaching' of this node.
     * 
     * @param item
     * @see #removeAndClean(MyTreeNode)
     */
    public void remove(T item);

    /**
     * Removes an item from the TreeView, detach its descendant, and remove the parent node if this node was the only
     * child of the parent. If this item has children, then all children are also removed.
     * 
     * @param item
     */
    public void removeAndClean(T item);

    /**
     * This method removes all empty folders. Empty folder can typically be created, when adding files. For instance, if
     * there is subfolder1/subolfer2, and subfolder2 is empty. Then it is not created. But avoiding to create also
     * subfolder1 needs to parse the whole hierarchy for each folder. Too long. It's quicker to clean afterwards.
     * 
     * @return true if at least one node is removed. The {@link #reload()} method is called.
     */
    public boolean cleanHierarchy();

    /**
     * <p>
     * Invoke this method if you've modified the TreeNodes upon which this model depends. The model will notify all of
     * its listeners that the model has changed. It will fire the events, necessary to update the layout caches and
     * repaint the tree. The tree will <i>not</i> be properly refreshed if you call the JTree.repaint instead.
     * </p>
     * <p>
     * This method will refresh the information about whole tree from the root. If only part of the tree should be
     * refreshed, it is more effective to call {@link #reload(TreeNode)}.
     * </p>
     * <p>
     * Note: code taken from the JDK DefaultTreeModel.
     * </p>
     */
    public void reload();

    /**
     * Invoke this method if you've modified the TreeNodes upon which this model depends. The model will notify all of
     * its listeners that the model has changed. It will fire the events, necessary to update the layout caches and
     * repaint the tree. The tree will <i>not</i> be properly refreshed if you call the JTree.repaint instead.
     * 
     * @param node - the tree node, from which the tree nodes have changed (inclusive). If you do not know this node,
     *            call {@link #reload()} instead.
     */
    public void reload(T node);

    /**
     * Returns the number of available columns.
     * 
     * @return Number of Columns
     */
    public int getColumnCount();

    /**
     * Returns the column name.
     * 
     * @param column Column number
     * @return Column name
     */
    public String getColumnName(int column);

    /**
     * Retrieves the default colum percentage size of a column, that is: its percentage of the available width.
     * 
     * @param col The index of the column to query.
     * @return the default size of the requested column.
     */
    public int getColumnSizePercentage(int col);

    /**
     * Returns the type (class) of a column.
     * 
     * @param column Column number
     * @return Class
     */
    public Class<?> getColumnClass(int column);

/**
     * Attach a new Object into the current hierarchy. This method is not mandatory. If not implemented, it should raise
     * an {@link IllegalStateException].
     * 
     * @param o
     * @return The total number of object added. It may be more than one, for instance, when adding a folder (including
     *         its descendants) in a file hierarchy
     * @throws IllegalStateException If this method is called on an instance, which doesn't possess this capability
     * @throws IllegalArgumentException If the given Object is not of the right type, to allow an attachment into the
     *             current hierarchy
     * @throws JUploadExceptionStopAddingFiles When an error occurs, indicating that not all files were added
     */
    public int attachObject(Object o) throws IllegalStateException, IllegalArgumentException,
            JUploadExceptionStopAddingFiles;

    // TODO Replace Object by a new parameterized type

    /**
     * Returns the value of a node in a column.
     * 
     * @param node Node
     * @param column Column number
     * @return Value of the node in the column
     */
    public Object getValueAt(T node, int column);

    /**
     * Check if a cell of a node in one column is editable.
     * 
     * @param node Node
     * @param column Column number
     * @return true/false
     */
    public boolean isCellEditable(T node, int column);

    /**
     * Sets a value for a node in one column.
     * 
     * @param aValue New value
     * @param node Node
     * @param column Column number
     */
    public void setValueAt(Object aValue, T node, int column);

    /**
     * @param tree the tree to set
     */
    // FIXME rename this method to setTableCellRenderer
    public void setTree(MyTreeTableCellRenderer tree);

    /**
     * This method must be called when one or more nodes are changed.
     * 
     * @param source - the Object responsible for generating the event (typically the creator of the event object passes
     *            this for its value)
     * @param path - a TreePath object that identifies the path to the parent of the modified item(s)
     * @param childIndices - an array of int that specifies the index values of the modified items
     * @param children - an array of Object containing the inserted, removed, or changed objects
     * @see TreeModelListener
     */
    public void fireTreeNodesChanged(Object source, TreePath path, int[] childIndices, T[] children);

    /**
     * This method must be called when one or more nodes are changed.
     * 
     * @param source - the Object responsible for generating the event (typically the creator of the event object passes
     *            this for its value)
     * @param path - a TreePath object that identifies the path to the parent of the modified item(s)
     * @param childIndices - an array of int that specifies the index values of the modified items
     * @param children - an array of Object containing the inserted, removed, or changed objects
     * @see TreeModelListener
     */
    public void fireTreeNodesInserted(Object source, TreePath path, int[] childIndices, T[] children);

    /**
     * This method must be called when one or more nodes are changed.
     * 
     * @param source - the Object responsible for generating the event (typically the creator of the event object passes
     *            this for its value)
     * @param path - a TreePath object that identifies the path to the parent of the modified item(s)
     * @param childIndices - an array of int that specifies the index values of the modified items
     * @param children - an array of Object containing the inserted, removed, or changed objects
     * @see TreeModelListener
     */
    public void fireTreeNodesRemoved(Object source, TreePath path, int[] childIndices, T[] children);

    /**
     * This method must be called when one or more nodes are changed.
     * 
     * @param source - the Object responsible for generating the event (typically the creator of the event object passes
     *            this for its value)
     * @param path - a TreePath object that identifies the path to the parent of the modified item(s)
     * @param childIndices - an array of int that specifies the index values of the modified items
     * @param children - an array of Object containing the inserted, removed, or changed objects
     * @see TreeModelListener
     */
    public void fireTreeStructureChanged(Object source, TreePath path, int[] childIndices, T[] children);

    /**
     * This method build a {@link TreePath} for the given item. This item should be in the current tree.
     * 
     * @param item
     * @return The build TreePath
     * @throws IllegalArgumentException If item is not in the tree represented by this model.
     */
    public TreePath getTreePath(T item);

    /**
     * Get the {@link TreePath} for the given object. This method is optional. It is typically only applicable if this
     * hierarchy maps on another hierarchy (for instance a hierarchy of files, based on a local file system)
     * 
     * @param o
     * @param createIntermediateNode true if intermediate nodes must be created during the process. false otherwise. In
     *            this case, if there are missing nodes, between the given object and the root, this method will return
     *            null.
     * @return The TreePath, with the last component being the node linked to the o object. It returns null, if this
     *         object is not in the hierarchy.
     * @throws IllegalStateException If this method is called on an instance, which doesn't possess this capability
     * @throws IllegalArgumentException If the given Object is not of the right type, to allow an attachment into the
     *             current hierarchy
     */
    public TreePath getTreePathForObject(Object o, boolean createIntermediateNode);
    // TODO Replace Object by a new parameterized type
}
