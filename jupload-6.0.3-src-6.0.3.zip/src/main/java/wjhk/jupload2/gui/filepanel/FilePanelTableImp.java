//
// $Id: FilePanelTableImp.java 1755 2015-08-17 11:57:13Z etienne_sf $
//
// jupload - A file upload applet.
// Copyright 2007 The JUpload Team
//
// Created: ?
// Creator: William JinHua Kwong
// Last modified: $Date: 2015-08-17 13:57:13 +0200 (lun., 17 août 2015) $
//
// This program is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version. This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
// details. You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software Foundation, Inc.,
// 675 Mass Ave, Cambridge, MA 02139, USA.
package wjhk.jupload2.gui.filepanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.io.File;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.TableColumnModel;
import javax.swing.tree.TreePath;

import wjhk.jupload2.exception.JUploadExceptionStopAddingFiles;
import wjhk.jupload2.filedata.FileData;
import wjhk.jupload2.gui.JUploadPanel;
import wjhk.jupload2.gui.filepanel.treeview.FileDataNode;
import wjhk.jupload2.gui.filepanel.treeview.FolderNode;
import wjhk.jupload2.gui.filepanel.treeview.FileDataTreeViewModel;
import wjhk.jupload2.gui.filepanel.treeview.MyTreeTable;
import wjhk.jupload2.gui.filepanel.treeview.MyTreeTableModel;
import wjhk.jupload2.gui.filepanel.treeview.MyTreeTableModelAdapter;
import wjhk.jupload2.gui.filepanel.treeview.TreeFileDataNode;
import wjhk.jupload2.policies.UploadPolicy;

/**
 * Implementation of the FilePanel : it creates the {@link wjhk.jupload2.gui.filepanel.FilePanelJFlatTable}, and handles
 * the necessary functionalities.<BR/>
 * Since version 6.0, this class manages the link with the hierarchical (tree) view of the files to upload. This class
 * remains the central point for file management, even if it's not visible. That is: even if the list displayed is the
 * hierarchical view.
 * 
 * @author William JinHua Kwong
 * @version $Revision: 1755 $
 */
public class FilePanelTableImp extends JPanel implements FilePanel, ComponentListener {

    /** A generated serialVersionUID, to avoid warning during compilation */
    static final long serialVersionUID = -8273990467324350526L;

    /** The main panel of the applet. */
    JUploadPanel juploadPanel = null;

    /** The table, for the flat list */
    FilePanelJFlatTable flatTable;

    /** the data model, for the flat list */
    FilePanelFlatDataModel2 flatModel;

    /** The table, for the tree view */
    MyTreeTable treeTable;

    /** the data model, for the tree view */
    MyTreeTableModel<TreeFileDataNode> /* FileDataTreeViewModel */treeModel;

    /** The view, which displays the flat view. */
    JScrollPane flatScrollPane = null;

    /** The view, which displays the tree view. */
    JScrollPane treeScrollPane = null;

    /** The current display mode, for the file list. The default value is FLAT */
    FileListViewMode fileListViewMode = FileListViewMode.FLAT;

    /** The current policy, always useful. */
    UploadPolicy uploadPolicy = null;

    /**
     * Creates a new instance.
     * 
     * @param juploadPanel The upload panel (parent).
     * @param uploadPolicy The upload policy to apply.
     */
    public FilePanelTableImp(JUploadPanel juploadPanel, UploadPolicy uploadPolicy) {
        this.juploadPanel = juploadPanel;
        this.uploadPolicy = uploadPolicy;

        setLayout(new BorderLayout());
        addMouseListener(juploadPanel.getMouseListener());
        setTransferHandler(juploadPanel.getTransferHandler());

        // Construction of the flat view
        this.flatTable = new FilePanelJFlatTable(juploadPanel, uploadPolicy);
        this.flatModel = new FilePanelFlatDataModel2(uploadPolicy);
        this.flatTable.setModel(this.flatModel);
        this.flatScrollPane = new JScrollPane(this.flatTable);
        this.flatScrollPane.addMouseListener(juploadPanel.getMouseListener());
        // We must resize columns, when the size of the view changes.
        this.flatScrollPane.getViewport().addComponentListener(this);

        // Construction of the tree view
        treeModel = new FileDataTreeViewModel(uploadPolicy, this.flatModel);
        treeTable = new MyTreeTable(treeModel);
        treeModel.setTree(treeTable.getTree());
        this.treeScrollPane = new JScrollPane(this.treeTable);
        this.treeScrollPane.addMouseListener(juploadPanel.getMouseListener());
        // We must resize columns, when the size of the view changes.
        this.treeScrollPane.getViewport().addComponentListener(this);

        // Let's display the chosen mode.
        this.fileListViewMode = this.uploadPolicy.getFileListViewMode();
        switch (this.fileListViewMode) {
            case FLAT:
                add(this.flatScrollPane, BorderLayout.CENTER);
                break;
            case TREE_VIEW:
            case INDEPENDENT_TREE_VIEW:
                add(this.treeScrollPane, BorderLayout.CENTER);
                break;
        }// switch
    }

    /** @see FilePanel#getFileListMode() */
    public FileListViewMode getFileListMode() {
        return this.fileListViewMode;
    }

    /** @see FilePanel#setFileListViewMode(wjhk.jupload2.gui.filepanel.FilePanel.FileListViewMode) */
    public void setFileListViewMode(FileListViewMode fileListViewMode) {
        if (this.fileListViewMode != fileListViewMode) {
            switch (fileListViewMode) {
                case FLAT:
                    remove(this.treeScrollPane);
                    add(this.flatScrollPane, BorderLayout.CENTER);
                    // this.flatScrollPane.setVisible(true);
                    // this.treeScrollPane.setVisible(false);
                    break;
                case TREE_VIEW:
                    remove(this.flatScrollPane);
                    add(this.treeScrollPane, BorderLayout.CENTER);
                    // this.flatScrollPane.setVisible(false);
                    // this.treeScrollPane.setVisible(true);
                    break;
                default:
                    IllegalArgumentException e = new IllegalArgumentException("Unknown value for fileListMode:"
                            + fileListViewMode.toString());
                    uploadPolicy.displayErr(e);
                    throw e;
            }
            this.fileListViewMode = fileListViewMode;
            this.uploadPolicy.setFileListViewMode(fileListViewMode);
        }
    }

    /**
     * @see wjhk.jupload2.gui.filepanel.FilePanel#addFiles(java.io.File[],java.io.File)
     */
    public final void addFiles(File[] filesToAdd) {
        // adding file can be long. Let's add a time counter, there...
        long startTime = System.currentTimeMillis();
        int nbFiles = 0;

        if (null == filesToAdd) {
            String msg = "FilePanelTableImpl: filesToUpload may not be null)";
            uploadPolicy.displayErr(msg);
            throw new java.lang.IllegalArgumentException(msg);
        } else {
            try {
                for (int i = 0; i < filesToAdd.length; i++) {
                    nbFiles += treeModel.attachObject(filesToAdd[i]);
                }// for
            } catch (JUploadExceptionStopAddingFiles e) { // The user want to stop here. Nothing else to do.
                this.uploadPolicy.displayWarn(getClass().getName() + ".addFiles() [" + e.getClass().getName() + "]: "
                        + e.getMessage());
            } catch (Exception e) {
                this.uploadPolicy.displayErr("Unexpected error during file adding: " + getClass().getName()
                        + ".addFiles() [" + e.getClass().getName() + "]: " + e.getMessage());
            }
        }
        this.juploadPanel.updateButtonState();

        // Update of the flat view
        this.flatModel.fireTableDataChanged();

        // Update of the tree view. In flat mode and tree_view mode, the visible root may have changed after adding
        // files.
        if (this.uploadPolicy.getFileListViewMode().equals(FileListViewMode.FLAT)
                || this.uploadPolicy.getFileListViewMode().equals(FileListViewMode.TREE_VIEW)) {
            TreePath treePath = treeModel.getTreePathForObject(flatModel.getFileRoot(), true);
            if (treePath == null) {
                uploadPolicy.displayErr("[Internal Error] treePath not found for folder "
                        + flatModel.getFileRoot().getAbsolutePath());
            } else {
                FolderNode visibleRoot = (FolderNode) treePath.getLastPathComponent();
                if (visibleRoot == null) {
                    uploadPolicy.displayErr("[Internal Error] Folder Node not found for folder "
                            + flatModel.getFileRoot().getAbsolutePath());
                } else {
                    treeModel.setRoot(visibleRoot);
                }
            }
        } else {
            // We still need to refresh the data
            reload();
        }

        // adding file can be long. Let's add a time counter, there...
        long finishTime = System.currentTimeMillis();
        uploadPolicy.displayInfo("Added " + nbFiles + " files in " + ((finishTime - startTime) / 1000) + " seconds");
    }

    /**
     * @see wjhk.jupload2.gui.filepanel.FilePanel#getFiles()
     */
    public final List<FileData> getFiles() {
        return this.flatModel.getFiles();
    }

    /**
     * @see wjhk.jupload2.gui.filepanel.FilePanel#getFilesLength()
     */
    public final int getFilesLength() {
        return this.flatTable.getRowCount();
    }

    /**
     * @see wjhk.jupload2.gui.filepanel.FilePanel#removeSelected()
     */
    public final void removeSelected() {
        synchronized (this.flatModel.getFiles()) {
            if (fileListViewMode.equals(FileListViewMode.FLAT)) {
                int[] rows = this.flatTable.getSelectedRows();
                for (int i = rows.length - 1; 0 <= i; i--) {
                    removeRowFromFlatView(rows[i], null);
                }
            } else {
                int[] rows = this.treeTable.getSelectedRows();
                for (int i = rows.length - 1; 0 <= i; i--) {
                    removeRowFromTreeView(rows[i]);
                }
            }
        }
        this.treeModel.cleanHierarchy();
        reload();
    }

    /**
     * @see java.awt.Container#removeAll()
     */
    @Override
    public final void removeAll() {
        synchronized (this.flatModel.getFiles()) {
            for (int i = getFilesLength() - 1; 0 <= i; i--) {
                removeRowFromFlatView(i, null);
            }
        }
        this.treeModel.cleanHierarchy();
        reload();
    }

    /** {@inheritDoc} */
    public void remove(List<FileData> files) {
        for (FileData fd : files) {
            removeRowFromFlatView(null, fd);
        }
        this.treeModel.cleanHierarchy();
        reload();
    }

    /** @see FilePanel#removeFileNotToUpload() */
    public void removeFileNotToUpload() {
        // We remove all files, for which getUploadFlag() returns false.
        // To do that, we can not do a standard for loop, to avoid the ConcurrentModificationException. So we do a
        // specific counter management.
        int i = 0;
        FileData fd;
        List<FileData> files = this.flatModel.getFiles();
        while (i < files.size()) {
            fd = files.get(i);
            if (fd.getUploadFlag()) {
                // This file is to be uploaded. Let's pass it, to check the next one.
                i += 1;
            } else {
                // This file is to be removed. We remove it, and keep the same index, which will contain the next file
                // in the next loop.
                removeRowFromFlatView(i, fd);
            }
        }// while
    }

    /**
     * Removes all occurences of a file from the list. Each file should only appear once here, but nobody knows !
     * 
     * @param fileData The file to remove
     */
    public final void remove(FileData fileData) {
        removeRowFromFlatView(null, fileData);
    }

    /**
     * Removes a File from the FileList, with either the rowNumber or the FileData (or both). This method is internal to
     * this class. If only one of these parameters is sent, the other one is calculated from the given one. If both
     * parameters are sent, it's up to the calling method to guaranty that they both represents the same FileData.
     * 
     * @param rowNumber The row number in the flat view.
     * @param fileData The fileData to remove.
     */
    final void removeRowFromFlatView(Integer rowNumberParam, FileData fileDataParam) {
        synchronized (this.flatModel.getFiles()) {
            if (rowNumberParam == null && fileDataParam == null) {
                uploadPolicy
                        .displayErr("rowNumberParam and fileDataParam may not be both null (in FilePanelTableImpl.removeRow(Integer,FileData)");
            }

            Integer rowNumber = rowNumberParam;
            FileData fileData = fileDataParam;
            if (rowNumber == null) {
                rowNumber = this.flatModel.getRow(fileDataParam);
            } else if (fileData == null) {
                fileData = this.flatModel.getFileDataAt(rowNumber);
            }

            // Removes the row, from the flat view .. If it exists.
            if (rowNumber == null || rowNumber < 0) {
                uploadPolicy.displayWarn("The row " + rowNumber
                        + " doesn't exist (in FilePanelTableImpl.removeRow(Integer,FileData)");
            } else {
                this.flatModel.removeRow(rowNumber);
            }

            // Removes the row, from the tree view
            if (fileData == null) {
                uploadPolicy.displayWarn("The fileData for " + rowNumber
                        + " doesn't exist (in FilePanelTableImpl.removeRow(Integer,FileData)");
            } else {
                uploadPolicy.displayDebug("removing file " + fileData.getAbsolutePath(), 10);
                try {
                    this.treeModel.remove(fileData.getTreeFileDataNode());
                } catch (Exception e) {
                    uploadPolicy.displayErr(e);
                }
            }
        }// synchronized
    }

    /**
     * Removes a File from the FileList in INDEPENDENT_TREE_VIEW mode, from its rowNumber
     * 
     * @param rowNumber The row number in the tree view.
     */
    final void removeRowFromTreeView(Integer rowNumber) {
        synchronized (this.flatModel.getFiles()) {
            @SuppressWarnings("unchecked")
            MyTreeTableModelAdapter<TreeFileDataNode> treeTableModelAdapter = (MyTreeTableModelAdapter<TreeFileDataNode>) this.treeTable
                    .getModel();
            TreeFileDataNode treeFileDataNode = treeTableModelAdapter.nodeForRow(rowNumber);
            // Ok, we've found the node to remove. But it can be a node or a file.
            if (treeFileDataNode instanceof FileDataNode) {
                // Let's remove one file
                removeRowFromFlatView(null, ((FileDataNode) treeFileDataNode).getFileData());
            } else {
                // Let's remove one folder. To avoid thread conflicts, we first get the list of FileData to remove, then
                // remove them.
                remove(((FolderNode) treeFileDataNode).getTotalFileDataChildren());
            }

        }// synchronized
    }

    /**
     * Clear the current selection in the JTable.
     */
    public final void clearSelection() {
        this.flatTable.clearSelection();
    }

    /** @see wjhk.jupload2.gui.filepanel.FilePanel#focusTable() */
    public final void focusTable() {
        if (0 < this.flatTable.getRowCount()) {
            this.flatTable.requestFocus();
        }
    }

    /** @see wjhk.jupload2.gui.filepanel.FilePanel#getFileDataAt(Point) */
    public FileData getFileDataAt(Point point) {
        int row = this.flatTable.rowAtPoint(point);
        return this.flatModel.getFileDataAt(row);
    }

    /**
     * Return the component on which drop event can occur. Used by {@link JUploadPanel}, when initializing the
     * DropTarget.
     * 
     * @return Component on which the drop event can occur.
     */
    public Component getDropComponent() {
        return this;
    }

    /**
     * Catches the <I>hidden</I> event on the JViewport. {@inheritDoc}
     */
    public void componentHidden(ComponentEvent arg0) {
        // We don't care...
    }

    /**
     * Catches the <I>moved</I> event on the JViewport. {@inheritDoc}
     */
    public void componentMoved(ComponentEvent arg0) {
        // We don't care...
    }

    /**
     * When the size of the file list (actually the JViewport) changes, we adapt the size if the columns. {@inheritDoc}
     */
    public void componentResized(ComponentEvent arg0) {
        // Is the width set?
        if (getWidth() > 0) {
            // First: we resize the flat table.
            TableColumnModel flatColumnModel = this.flatTable.getColumnModel();
            for (int i = 0; i < this.flatModel.getColumnCount(); i++) {
                flatColumnModel.getColumn(i)
                        .setPreferredWidth(
                                (this.flatModel.getColumnSizePercentage(i) * this.flatScrollPane.getViewport()
                                        .getWidth()) / 100);
            }// for

            // Then the tree view
            TableColumnModel treeviewColumnModel = this.treeTable.getColumnModel();
            for (int i = 0; i < this.treeModel.getColumnCount(); i++) {
                treeviewColumnModel.getColumn(i)
                        .setPreferredWidth(
                                (this.treeModel.getColumnSizePercentage(i) * this.treeScrollPane.getViewport()
                                        .getWidth()) / 100);
            }// for
        }
    }

    /**
     * Catches the <I>shown</I> event on the JViewport. {@inheritDoc}
     */
    public void componentShown(ComponentEvent arg0) {
        // We don't care...
    }

    /**
     * Set color of files list grid border.
     * 
     * @param color awt Color
     */
    public void setGridBorderColor(Color color) {
        this.flatTable.setGridColor(color);
    }

    /**
     * Set back color of table header
     * 
     * @param color awt Color
     */
    public void setTableHeaderBackColor(Color color) {
        this.flatTable.getTableHeader().setBackground(color);
    }

    /**
     * Set table header text font
     * 
     * @param color awt Color
     */
    public void setTableHeaderFont(Font font) {
        this.flatTable.getTableHeader().setFont(font);
    }

    /**
     * Set text color of table header
     * 
     * @param color awt Color
     */
    public void setTableHeaderTextColor(Color color) {
        this.flatTable.getTableHeader().setForeground(color);
    }

    /** {@inheritDoc} */
    public void reload() {
        this.treeModel.reload();
    }

    /** {@inheritDoc} */
    public void cleanHierarchy() {
        this.treeModel.cleanHierarchy();
        reload();
    }

}
