//
// $Id$
//
// jupload - A file upload applet.
//
// Copyright 2015 The JUpload Team
//
// Created: 7 févr. 2015
// Creator: etienne_sf
// Last modified: $Date$
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

package wjhk.jupload2.gui.filepanel.treeview;

import java.util.Date;

import wjhk.jupload2.gui.filepanel.FilePanelFlatDataModel2;
import wjhk.jupload2.policies.UploadPolicy;

/**
 * This class is the root of JUPload of the file system. This allows to manage the difference between Unix and Windows:
 * there is one root on unix, and potential several on windows. This root is virtual, and is the parent for '/' (on
 * Unix) and for C:\, D:\ (...) on windows.
 * 
 * @author etienne_sf
 */
public class RootNode extends FolderNode {

    public RootNode(UploadPolicy uploadPolicy, MyTreeTableModel<TreeFileDataNode> model,
            FilePanelFlatDataModel2 flatModel) {
        super(uploadPolicy, model, flatModel);
    }

    public String getFileName() {
        return "";
    }

    public Date getLastModified() {
        return null;
    }

    public String getDirectory() {
        return "";
    }

    public boolean canRead() {
        return false;
    }

}
