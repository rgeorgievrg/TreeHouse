//
// $Id$
//
// jupload - A file upload applet.
//
// Copyright 2015 The JUpload Team
//
// Created: 6 févr. 2015
// Creator: etienne_sf
// Last modified: $Date$
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

package wjhk.jupload2.gui.filepanel.treeview;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import wjhk.jupload2.exception.JUploadException;
import wjhk.jupload2.exception.JUploadIOException;
import wjhk.jupload2.filedata.FileData;
import wjhk.jupload2.gui.filepanel.FilePanelFlatDataModel2;
import wjhk.jupload2.upload.helper.ByteArrayEncoder;

/**
 * @author etienne_sf
 */
public class FileDataNode implements TreeFileDataNode {

    /** The mode which manages this node. Used to fire events, when nodes are changed */
    MyTreeTableModel<TreeFileDataNode> treeModel = null;

    /**
     * The flat list file is still responsible to manage the final list of files to download. So each
     * {@link FileDataNode} creation (as a child of FolderNode) must trigger adding a row into the flat list. This is
     * done through its TableModel, this attribute.
     * 
     * @see #addChild(File)
     */
    FilePanelFlatDataModel2 flatModel = null;

    /** The {@link FileData} instance to which all calls to the {@link FileData} interface are delegated. */
    FileData fileData = null;

    /**
     * Contains the parent of this node, in the hierarchy. May be null, if this node has not been attached to a hierachy
     * yet.
     */
    TreeFileDataNode parent = null;

    /**
     * @param fileData The {@link FileData} instance to which all calls to the {@link FileData} interface are delegated
     */
    public FileDataNode(FileData fileData) {
        this.fileData = fileData;
        fileData.setTreeFileDataNode(this);
    }

    /** @see TreeFileDataNode#getTotalChildCount() */
    public int getTotalChildCount() {
        return 0;
    }

    public List<MyTreeNode> getChildren() {
        return new ArrayList<MyTreeNode>(0);
    }

    public FileData getFileData() {
        return fileData;
    }

    public void appendFileProperties(ByteArrayEncoder bae, int index) throws JUploadIOException {
        fileData.appendFileProperties(bae, index);
    }

    public void beforeUpload(String uploadFileRoot) throws JUploadException {
        fileData.beforeUpload(uploadFileRoot);
    }

    public long getUploadLength() {
        return fileData.getUploadLength();
    }

    public void afterUpload() {
        fileData.afterUpload();
    }

    public InputStream getInputStream() throws JUploadException {
        return fileData.getInputStream();
    }

    public String getFileName() {
        return fileData.getFileName();
    }

    public String getFileExtension() {
        return fileData.getFileExtension();
    }

    public long getFileLength() {
        return fileData.getFileLength();
    }

    public Date getLastModified() {
        return fileData.getLastModified();
    }

    public boolean getUploadFlag() {
        return fileData.getUploadFlag();
    }

    public void setUploadFlag(boolean uploadFlag) {
        if (fileData.getUploadFlag() != uploadFlag) {
            // Let's update the FileData
            fileData.setUploadFlag(uploadFlag);
            if (treeModel != null) {
                treeModel.fireTreeNodesChanged(this, treeModel.getTreePath((TreeFileDataNode) getParent()),
                        FolderNode.getIntArray((getParent().getChildren()).indexOf(this)),
                        FolderNode.getItemArray((TreeFileDataNode) this));
            }
        }
    }

    public String getDirectory() {
        return fileData.getDirectory();
    }

    public String getMD5() throws JUploadException {
        return fileData.getMD5();
    }

    public String getMimeType() {
        return fileData.getMimeType();
    }

    public boolean canRead() {
        return fileData.canRead();
    }

    public File getFile() {
        throw new IllegalAccessError("Internal error: getFile is deprecated and should not be called from "
                + this.getClass().getName());
    }

    public String getRelativeDir() {
        return fileData.getRelativeDir();
    }

    public String getAbsolutePath() {
        return FolderNode.getAbsolutePath(this);
    }

    public boolean isPreparedForUpload() {
        return fileData.isPreparedForUpload();
    }

    public int getChildCount() {
        return 0;
    }

    public MyTreeNode getChild(int index) {
        return null;
    }

    public MyTreeNode getChild(String name) {
        // There are no Children, here...
        return null;
    }

    public MyTreeNode getParent() {
        return this.parent;
    }

    /** @see MyTreeNode#setParent(MyTreeNode) */
    public void setParent(MyTreeNode parent) {
        this.parent = (TreeFileDataNode) parent;
    }

    /** @see MyTreeNode#setTreeModel(TreeModel) */
    @SuppressWarnings("unchecked")
    public void setTreeModel(TreeModel model) {
        this.treeModel = (MyTreeTableModel<TreeFileDataNode>) model;
    }

    /** {@inheritDoc} */
    public void setFlatModel(FilePanelFlatDataModel2 flatModel) {
        this.flatModel = flatModel;
    }

    public void removeChild(MyTreeNode child) {
        throw new IllegalArgumentException(this.getClass().getName() + " can't have children");
    }

    public boolean isLeaf() {
        return true;
    }

    /**
     * Important: this method is called by the JTree class, as the 'main' name for the node.
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return getFileName();
    }

    public TreeFileDataNode getTreeFileDataNode() {
        return this;
    }

    public void setTreeFileDataNode(TreeFileDataNode node) {
        throw new IllegalStateException("setTreeFileDataNode may not be called againts a " + this.getClass().getName());
    }

    public TreePath getTreePath() {
        if (parent == null) {
            return new TreePath(this);
        } else {
            return parent.getTreePath().pathByAddingChild(this);
        }
    }
}
