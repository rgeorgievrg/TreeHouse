package wjhk.jupload2.gui.filepanel.treeview;

import java.awt.Dimension;

import javax.swing.JTable;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * This class is a generic class. It has not been adapted for JUpload. It's directly taken from Jörn Hameister tutorial<BR/>
 * After the data model, the auxiliary components and the Main-Class are now missing is the actual TreeTable. For this
 * purpose, the class is MyTreeTable created. This inherits from JTable . Since Java Multiple inheritance is not
 * possible, the Tree component via an association in the class is MyTreeTableCellRenderer involved. The data model
 * MyAbstractTreeTableModel is both the MyTreeTableCellRenderer (Tree) and on the Object MyTreeTableModelAdapter passed
 * (Table). As a model, the class is MyTreeTableModelAdapter set. For simultaneously selecting Tree and Table is
 * MyTreeTableSelectionModel for Tree and Table used. Then a default renderer for the tree and set a default editor for
 * the table must be set.
 * 
 * @author Jörn Hameister
 */
public class MyTreeTable extends JTable {

    private static final long serialVersionUID = 1L;

    private MyTreeTableCellRenderer tree;

    @SuppressWarnings({
            "rawtypes", "unchecked"
    })
    public MyTreeTable(MyTreeTableModel<? extends MyTreeNode> treeTableModel) {
        super();

        // JTree erstellen.
        tree = new MyTreeTableCellRenderer(this, treeTableModel);

        // Modell setzen.
        super.setModel(new MyTreeTableModelAdapter(treeTableModel, tree));

        // Gleichzeitiges Selektieren fuer Tree und Table.
        MyTreeTableSelectionModel selectionModel = new MyTreeTableSelectionModel();
        tree.setSelectionModel(selectionModel); // For the tree
        setSelectionModel(selectionModel.getListSelectionModel()); // For the table

        // Renderer fuer den Tree.
        setDefaultRenderer(MyTreeTableModel.class, tree);
        // Editor fuer die TreeTable
        setDefaultEditor(MyTreeTableModel.class, new MyTreeTableCellEditor(tree, this));

        // Kein Grid anzeigen.
        setShowGrid(false);

        // Keine Abstaende.
        setIntercellSpacing(new Dimension(0, 0));
    }

    /**
     * @return the tree
     */
    public MyTreeTableCellRenderer getTree() {
        return tree;
    }

}
