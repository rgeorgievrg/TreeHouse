package wjhk.jupload2.gui.filepanel.treeview;

import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.TreePath;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * From Jörn sample, the main modifications are:
 * <UL>
 * <LI>Add of an even Listener, to report data modifications to the table.</LI>
 * <UL>
 * <BR/>
 * Since Java Swing GUI components also still needed a model that actually is not equal to the data model, is now a
 * class MyTreeTableModelAdapter which of AbstractTableModel inherits created. This class will be later in the class
 * MyTreeTable as a model for the JTable uses. If the TreeTable later for values ​​asks to be displayed, it must be
 * determined whether the requested values ​​of the tree or directly from the data model
 * MyAbstractTreeTableModel<MyHierarchicalNode> can be delivered. In addition, in the class, nor is
 * TreeExpansionListener created and registered. This responds to clicks in the tree and makes dafüf that the tree is up
 * and closed.
 * 
 * @author Jörn Hameister
 */
public class MyTreeTableModelAdapter<T extends MyTreeNode> extends AbstractTableModel {

    private static final long serialVersionUID = 1L;

    JTree tree;

    MyTreeTableModel<T> treeTableModel;

    public MyTreeTableModelAdapter(MyTreeTableModel<T> treeTableModel, JTree tree) {
        this.tree = tree;
        this.treeTableModel = treeTableModel;

        // Registration of a new TreeExpansionListener, for the JTree
        tree.addTreeExpansionListener(new TreeExpansionListener() {
            public void treeExpanded(TreeExpansionEvent event) {
                fireTableDataChanged();
            }

            public void treeCollapsed(TreeExpansionEvent event) {
                fireTableDataChanged();
            }
        });

        treeTableModel.addTreeModelListener(new TreeModelListener() {

            public void treeNodesChanged(TreeModelEvent e) {
                fireTableDataChanged();
            }

            public void treeNodesInserted(TreeModelEvent e) {
                fireTableDataChanged();
            }

            public void treeNodesRemoved(TreeModelEvent e) {
                fireTableDataChanged();
            }

            public void treeStructureChanged(TreeModelEvent e) {
                fireTableDataChanged();
            }

        });
    }

    public int getColumnCount() {
        return treeTableModel.getColumnCount();
    }

    public String getColumnName(int column) {
        return treeTableModel.getColumnName(column);
    }

    public Class<?> getColumnClass(int column) {
        return treeTableModel.getColumnClass(column);
    }

    public int getRowCount() {
        return tree.getRowCount();
    }

    @SuppressWarnings("unchecked")
    public T nodeForRow(int row) {
        TreePath treePath = tree.getPathForRow(row);
        return (treePath == null) ? null : (T) treePath.getLastPathComponent();
    }

    public Object getValueAt(int row, int column) {
        return treeTableModel.getValueAt(nodeForRow(row), column);
    }

    public boolean isCellEditable(int row, int column) {
        return treeTableModel.isCellEditable(nodeForRow(row), column);
    }

    public void setValueAt(Object value, int row, int column) {
        treeTableModel.setValueAt(value, nodeForRow(row), column);
    }
}