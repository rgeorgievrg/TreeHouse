//
// $Id$
//
// jupload - A file upload applet.
//
// Copyright 2015 The JUpload Team
//
// Created: 7 févr. 2015
// Creator: etienne_sf
// Last modified: $Date$
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

package wjhk.jupload2.gui.filepanel.treeview;

import java.util.List;

import javax.swing.event.TreeModelEvent;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import wjhk.jupload2.gui.filepanel.FilePanelFlatDataModel2;

/**
 * @author etienne_sf
 */
public interface MyTreeNode {

    /**
     * Returns the list of direct children for this node
     *
     * @return the children for this node
     */
    List<MyTreeNode> getChildren();

    /**
     * Returns the number of direct children for this node
     * 
     * @return Number of direct children
     */
    int getChildCount();

    /**
     * Returns the number of children (direct children children of children...) for this node
     * 
     * @return Number of direct children
     */
    public int getTotalChildCount();

    /**
     * Get the child with the given index number, from the direct children of this node
     * 
     * @param index
     * @return
     */
    public MyTreeNode getChild(int index);

    /**
     * Get the child with the name, from the direct children of this node.
     * 
     * @param name The name of the item we're looking for. For a file, it's the filename, not the absolute path.
     * @return The child with this name, or null of no such child exists
     */
    public MyTreeNode getChild(String name);

    /**
     * Returns the parent for this node.
     * 
     * @return
     */
    public MyTreeNode getParent();

    /**
     * Sets the parent for this node.
     * 
     * @return
     */
    public void setParent(MyTreeNode parent);

    /**
     * Sets the tree model for the current node. Necessary to properly send the {@link TreeModelEvent}.
     * 
     * @param model The model in which this node is, and to which {@link TreeModelEvent} must be sent.
     */
    public void setTreeModel(TreeModel model);

    /**
     * Sets the flat model for the current node. It is necessary, as this flat model must be kept synchronized with the
     * tree model. Each adding o f a child in the tree, must also be done in the flat model.
     * 
     * @param model The model, which must be kept synchronized.
     */
    public void setFlatModel(FilePanelFlatDataModel2 model);

    /**
     * Removes a child from the children of this node.
     * 
     * @param child The child to remove
     * @throws IllegalArgumentException If child is not an actual child of the current {@link FolderNode}.
     */
    public void removeChild(MyTreeNode child);

    /** Indicates whether this node has children or not ('terminal' node) */
    boolean isLeaf();

    /**
     * Get the {@link TreePath} for this node, in the hierarchy.
     * 
     * @return
     */
    public TreePath getTreePath();

}
