//
// $Id$
//
// jupload - A file upload applet.
//
// Copyright 2015 The JUpload Team
//
// Created: 6 févr. 2015
// Creator: etienne_sf
// Last modified: $Date$
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

package wjhk.jupload2.gui.filepanel.treeview;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import wjhk.jupload2.exception.JUploadException;
import wjhk.jupload2.exception.JUploadExceptionStopAddingFiles;
import wjhk.jupload2.exception.JUploadIOException;
import wjhk.jupload2.filedata.FileData;
import wjhk.jupload2.gui.filepanel.FilePanelFlatDataModel2;
import wjhk.jupload2.policies.UploadPolicy;
import wjhk.jupload2.upload.helper.ByteArrayEncoder;

/**
 * @author etienne_sf
 */
public class FolderNode implements TreeFileDataNode {

    /** The mode which manages this node. Used to fire events, when nodes are changed */
    // FIXME Remove the model ref. Let the model generate all relevant messages (would correct bugs and be quicker)!
    MyTreeTableModel<TreeFileDataNode> treeModel = null;

    /**
     * The flat list file is still responsible to manage the final list of files to download. So each
     * {@link FileDataNode} creation (as a child of FolderNode) must trigger adding a row into the flat list. This is
     * done through its TableModel, this attribute.
     * 
     * @see #addChild(File)
     */
    FilePanelFlatDataModel2 flatModel = null;

    /** The {@link FileData} instance to which all calls to the {@link FileData} interface are delegated. */
    File file = null;

    /**
     * Contains the parent of this node, in the hierarchy. May be null, if this node has not been attached to a hierachy
     * yet.
     */
    TreeFileDataNode parent = null;

    /** The list of children, for this folder */
    List<TreeFileDataNode> children = null;

    Date fileModified;

    boolean uploadFlag = true;

    UploadPolicy uploadPolicy = null;

    /**
     * Returns the filename of the file. This utility method is specially used, to manage root folders. For instance new
     * File("E:\\").getName() returns the empty String, instead of "E:\"!
     * 
     * @param f
     * @return The filename, when File.getname() returns a non empty String. Otherwise, it returns File.getCanonical()
     *         (for instance, C:\ for a root in Windows)
     */
    static public String getFilename(File file) {
        String filename = file.getName();
        try {
            filename = (filename.equals("")) ? file.getCanonicalPath() : filename;
        } catch (IOException e) {
            throw new IllegalArgumentException(e.getMessage()
                    + " exception, when trying to resolve the canonical path for " + file.getAbsolutePath(), e);
        }
        return filename;
    }

    /**
     * Retrieves the Absolute Path of a node, within the current visible hierarchy. All node names are concatanated,
     * separated by {@link File#separator}. The path starts with a leading {@link File#separator}.
     * 
     * @param node
     * @return
     */
    static public String getAbsolutePath(TreeFileDataNode node) {
        StringBuffer sb = new StringBuffer();
        int depth = 0;
        for (Object o : node.getTreePath().getPath()) {
            String oName = o.toString();

            sb.append(oName);
            // We add a Separator, if relevant:
            if (depth == 1 && oName.substring(1, 2).equals(":")) {
                // Windows Root (C:, D:...).
                // Our FolderNode already contains the trailing slash, we don't add it.
                // Than, as we already added a leading slah, we must remove it:
                sb.setLength(0);
                sb.append(oName);
            } else if (o != node) {
                // We don't add the trailing slash, after the last path component.
                sb.append(File.separator);
            }
            depth += 1;
        }
        return sb.toString();
    }

    public static int[] getIntArray(int... indexOf) {
        int[] ints = new int[indexOf.length];
        for (int i = 0; i < indexOf.length; i += 1) {
            ints[i] = indexOf[i];
        }
        return ints;
    }

    public static TreeFileDataNode[] getItemArray(TreeFileDataNode... child) {
        TreeFileDataNode[] treeNodes = (TreeFileDataNode[]) Array.newInstance(TreeFileDataNode.class, child.length);
        for (int i = 0; i < child.length; i += 1) {
            treeNodes[i] = child[i];
        }
        return treeNodes;
    }

    protected FolderNode(UploadPolicy uploadPolicy, MyTreeTableModel<TreeFileDataNode> model,
            FilePanelFlatDataModel2 flatModel) {
        this.uploadPolicy = uploadPolicy;
        this.treeModel = model;
        this.flatModel = flatModel;
        this.children = new ArrayList<TreeFileDataNode>();
    }

    /**
     * Creates a node, with no link to any parent. This constructor add no children (subfolders, files) to the newly
     * created FolderNode.
     * 
     * @param file The {@link FileData} instance to which all calls to the {@link FileData} interface are delegated
     */
    public FolderNode(File file, UploadPolicy uploadPolicy, MyTreeTableModel<TreeFileDataNode> model,
            FilePanelFlatDataModel2 flatModel) {
        // First: call the default constructor.
        this(uploadPolicy, model, flatModel);

        if (!file.isDirectory()) {
            throw new IllegalArgumentException("Internal error: " + file.getAbsolutePath() + " should be a folder");
        }
        this.file = file;
    }

    /** @see TreeFileDataNode#getTotalChildCount() */
    public int getTotalChildCount() {
        int total = 0;
        for (TreeFileDataNode child : children) {
            total += 1 + child.getTotalChildCount();
        }
        return total;
    }

    @SuppressWarnings("unchecked")
    /** {@inheritDoc} */
    public List<MyTreeNode> getChildren() {
        return (List<MyTreeNode>) (List<?>) children;
    }

    /** {@inheritDoc} */
    public void appendFileProperties(ByteArrayEncoder bae, int index) throws JUploadIOException {
        throw new IllegalAccessError("Internal error: appendFileProperties should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public void beforeUpload(String uploadPathRoot) throws JUploadException {
        throw new IllegalAccessError("Internal error: beforeUpload should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public long getUploadLength() {
        throw new IllegalAccessError("Internal error: getUploadLength should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public void afterUpload() {
        throw new IllegalAccessError("Internal error: afterUpload should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public InputStream getInputStream() throws JUploadException {
        throw new IllegalAccessError("Internal error: getInputStream should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public String getFileName() {
        // We must use the static method, to properly resolve all folder kinds, especially the windows file system root
        // (C:, D:..)
        return FolderNode.getFilename(file);
    }

    /** {@inheritDoc} */
    public String getFileExtension() {
        throw new IllegalAccessError("Internal error: getFileExtension should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public long getFileLength() {
        return -1;
    }

    /** {@inheritDoc} */
    public Date getLastModified() {
        if (this.fileModified == null) {
            this.fileModified = new Date(this.file.lastModified());
        }
        return this.fileModified;
    }

    /** {@inheritDoc} */
    public boolean getUploadFlag() {
        return uploadFlag;
    }

    /** {@inheritDoc} */
    public void setUploadFlag(boolean uploadFlag) {
        if (this.uploadFlag != uploadFlag) {
            this.uploadFlag = uploadFlag;
            for (TreeFileDataNode tfdn : children) {
                tfdn.setUploadFlag(uploadFlag);
            }
            if (getParent() == null) {
                // Special management for root change
                treeModel.fireTreeNodesChanged(this, null, null, null);
            } else {
                treeModel.fireTreeNodesChanged(this, treeModel.getTreePath((TreeFileDataNode) getParent()),
                        getIntArray((getParent().getChildren()).indexOf(this)), getItemArray((TreeFileDataNode) this));
            }
        }
    }

    /** {@inheritDoc} */
    public String getDirectory() {
        return this.file.getAbsoluteFile().getParent();
    }

    /** {@inheritDoc} */
    public String getMD5() throws JUploadException {
        throw new IllegalAccessError("Internal error: getMD5 should not be called from " + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public String getMimeType() {
        throw new IllegalAccessError("Internal error: getMimeType should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public boolean canRead() {
        return file.canRead();
    }

    protected File getFile() {
        throw new IllegalAccessError("Internal error: getFile is deprecated and should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public String getRelativeDir() {
        throw new IllegalAccessError("Internal error: getRelativeDir should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public String getAbsolutePath() {
        return FolderNode.getAbsolutePath(this);
    }

    /** {@inheritDoc} */
    public boolean isPreparedForUpload() {
        throw new IllegalAccessError("Internal error: isPreparedForUpload should not be called from "
                + this.getClass().getName());
    }

    /** {@inheritDoc} */
    public int getChildCount() {
        return (children == null) ? 0 : children.size();
    }

    /** {@inheritDoc} */
    public TreeFileDataNode getChild(int index) {
        return (children == null) ? null : children.get(index);
    }

    /** {@inheritDoc} */
    public TreeFileDataNode getChild(String name) {
        for (TreeFileDataNode node : children) {
            if (node.getFileName().equals(name)) {
                return node;
            }
        }// for

        // No child with name...
        return null;
    }

    /** {@inheritDoc} */
    public TreeFileDataNode getChild(File file) {
        return getChild(FolderNode.getFilename(file));
    }

    /** {@inheritDoc} */
    public MyTreeNode getParent() {
        return this.parent;
    }

    /** {@inheritDoc} */

    public void setParent(MyTreeNode parent) {
        this.parent = (TreeFileDataNode) parent;
    }

    /** @see MyTreeNode#setTreeModel(TreeModel) */
    @SuppressWarnings("unchecked")
    public void setTreeModel(TreeModel model) {
        this.treeModel = (MyTreeTableModel<TreeFileDataNode>) model;
    }

    /** {@inheritDoc} */
    public void setFlatModel(FilePanelFlatDataModel2 flatModel) {
        this.flatModel = flatModel;
    }

    /**
     * Removes one child from the children list.
     * 
     * @see wjhk.jupload2.gui.filepanel.treeview.MyTreeNode#removeChild(wjhk.jupload2.gui.filepanel.treeview.MyTreeNode)
     */
    public void removeChild(MyTreeNode child) {
        if (!children.remove(child)) {
            throw new IllegalArgumentException(child.toString() + " is not a child of " + getFileName());
        }
        // if (fireTreeModelEvent && model != null) {
        // model.fireTreeNodesRemoved(this, model.getTreePath(this), indexes, itemRemoved);
        // FIXME this must be very expensive. But it works. To be optimized.
        // model.reload(this);
        // }
        // Let's separate this node from the context. This is necessary, to avoid memory leak.
        child.setParent(null);
        child.setTreeModel(null);
        child.setFlatModel(null);

        // If the child to detach is a FolderNode, we must also detach all its children, to avoid memory leak. It will
        // be done recursively, for all descendants.
        while (child.getChildCount() > 0) {
            // If child has children, it is a FolderNode
            ((FolderNode) child).removeChild(child.getChild(0));
        }// while
    }

    /**
     * This method adds a new FileData in the children list, for the current object. It checks if this the given child
     * has already been created. If yes, it displays a warning, and returns it. If node, it created a new node, and add
     * it to the children list for this node.
     * 
     * @param node
     */
    public TreeFileDataNode addChild(FileData fileData) {
        return addChild(new FileDataNode(fileData));
    }

    /**
     * Add a new child to the children of this folder. It first checks that this child doesn't already exists. If yes,
     * an error is displayed.
     * 
     * @param child
     * @return
     */
    public TreeFileDataNode addChild(TreeFileDataNode child) {
        TreeFileDataNode alreadyExistingChild = (TreeFileDataNode) getChild(child.getFileName());
        if (alreadyExistingChild == null) {
            // This child is not already a child of this folder.
            children.add(child);
            child.setTreeModel(this.treeModel);
            child.setParent(this);
            treeModel.fireTreeNodesInserted(this, treeModel.getTreePath(this), getIntArray(children.indexOf(child)),
                    getItemArray((TreeFileDataNode) child));
            return child;
        } else {
            uploadPolicy.displayWarn("The FileData for " + child.getAbsolutePath() + " already exists for the folder "
                    + getFileName());
            return alreadyExistingChild;
        }
    }

    /**
     * This method checks if this the given subfolder has already been created. And it returns it, if it wasn't. The new
     * node is also added to the children list of this node.
     * 
     * @param node
     */
    public FolderNode getSubfolderOrCreateIt(File file) throws JUploadExceptionStopAddingFiles {
        if (!file.isDirectory()) {
            throw new JUploadExceptionStopAddingFiles(file.getAbsolutePath() + " must be a directory");
        }
        TreeFileDataNode child = addChild(new FolderNode(file, uploadPolicy, treeModel, flatModel));

        if (!(child instanceof FolderNode)) {
            throw new JUploadExceptionStopAddingFiles("A child with the same name (" + file.getName()
                    + ") already exists, but is not a folder");
        } else {
            return (FolderNode) child;
        }
    }

    /** {@inheritDoc} */
    public boolean isLeaf() {
        return false;
    }

    /**
     * Important: this method is called by the JTree class, as the 'main' name for the node.
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return getFileName();
    }

    /** {@inheritDoc} */
    public TreeFileDataNode getTreeFileDataNode() {
        return this;
    }

    /** {@inheritDoc} */
    public void setTreeFileDataNode(TreeFileDataNode node) {
        throw new IllegalStateException("setTreeFileDataNode may not be called againts a FolderNode");
    }

    /** {@inheritDoc} */
    public TreePath getTreePath() {
        if (parent == null) {
            return new TreePath(this);
        } else {
            return parent.getTreePath().pathByAddingChild(this);
        }
    }

    /**
     * Adds a given file as a Child of the current node. This file may or may not be in the file of the parent node.
     * 
     * @param f The file to add. If f is a folder, none of its descendants (files, folders) will be added. Only f is
     *            added.
     * @return The created child
     * @throws JUploadExceptionStopAddingFiles
     */
    public TreeFileDataNode addChild(File f) throws JUploadExceptionStopAddingFiles {
        if (getChild(f) != null) {
            throw new JUploadExceptionStopAddingFiles("Internal error: " + f.getAbsolutePath()
                    + " is already a child of the node for " + this.file.getAbsolutePath());
        }
        // It's not already a child of this node. We add it.
        if (f.isDirectory()) {
            return addChild(new FolderNode(f, uploadPolicy, treeModel, flatModel));
        } else {
            FileData fd = flatModel.addFile(f);
            return addChild(new FileDataNode(fd));
        }
    }

    /**
     * Adds a given file as a Child of the current node. This file may or may not be in the file of the parent node.
     * 
     * @param f The file to add.
     * @return The total number of files that have been added, not counting the folders.
     * @throws JUploadExceptionStopAddingFiles
     */
    public int addChildAndDescendants(File f) throws JUploadExceptionStopAddingFiles {
        int nbFiles = 0;

        TreeFileDataNode child = getChild(f);
        if (child == null) {
            // It's not already a child of this node. We add it.
            if (f.isDirectory()) {
                child = addChild(f);
            } else {
                FileData fd = flatModel.addFile(f);
                // The upload policy may decide to not add this file. In this case, fd is null
                if (fd != null) {
                    child = addChild(new FileDataNode(fd));
                    fd.setTreeFileDataNode(child);
                    nbFiles += 1;
                }
            }
        }

        // If it's a folder, we need to add all its children (whether or not this FolderNode already existed in the
        // hierarchy), as we need to be also sure that all descendant are in the hierarchy.
        if (f.isDirectory()) {
            // We add files here, in order to calculate nbFiles
            for (File file : f.listFiles()) {
                nbFiles += ((FolderNode) child).addChildAndDescendants(file);
            } // for
        }
        return nbFiles;
    }

    /**
     * Returns all {@link FileData} found as child of these node, or any of its sub-folder, sub-sub-folders... In other
     * words, it gets all {@link FileData} in the whole hierarchy below this node.
     * 
     * @return
     */
    public List<FileData> getTotalFileDataChildren() {
        List<FileData> files = new ArrayList<FileData>();
        
        for (MyTreeNode tfdn : getChildren()) {
            if (tfdn instanceof FileDataNode) {
                // We found a new FileData, let's add it to our list.
                files.add(((FileDataNode) tfdn).getFileData());
            } else {
                // A folder: we dig one step further.
                files.addAll(((FolderNode) tfdn).getTotalFileDataChildren());
            }
        }
        return files;
    }

}
