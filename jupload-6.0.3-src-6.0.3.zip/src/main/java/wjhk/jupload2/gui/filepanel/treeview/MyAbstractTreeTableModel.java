package wjhk.jupload2.gui.filepanel.treeview;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTree;
import javax.swing.event.EventListenerList;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import wjhk.jupload2.policies.UploadPolicy;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * From Jörn sample, the main modifications are:
 * <UL>
 * <LI>Use of the uploadPolicy</LI>
 * <LI>Add of the getRoot and setRoot methods</LI>
 * <LI>Capability to remove an item</LI>
 * <LI>Transformation in a generic type</LI>
 * <UL>
 * <BR/>
 * In the next step, the interface is MyTreeTableModel to the abstract class MyAbstractTreeTableModel expanded. In this
 * class, the Wuzelknoten (root) is stored, there is a method for checking whether child nodes are available and manages
 * all event listener verwerden. The EventListener ensure that structural changes in the data model will be forwarded to
 * the tree and displayed.<BR/>
 * <B>Note:</B> We can not use the DefaultTreeModel for various model. One is that we need multiple columns. Another one
 * is that we must delegate the content to the FilePanel, as the view may be flat or treeview. So we stay with the
 * implementation which existed before the tree view, there would otherwise be too much changes in the applet code.
 * 
 * @author Jörn Hameister
 */
public abstract class MyAbstractTreeTableModel<T extends MyTreeNode> implements MyTreeTableModel<T> {

    UploadPolicy uploadPolicy = null;

    /** The {@link JTree} which contains the data for this model */
    MyTreeTableCellRenderer tree = null;

    /**
     * The absolute root of the hierarchical structure. It can't be delegated to the tree table, as the displayed root
     * can change, when adding other files to upload.<BR/>
     * Note: on Windows, there can be several roots. So the JUpload's absolute root is a non existing folder, which
     * contain one folder under Unix ('/') and may contain several folders under Windows ('C:\', 'D:\'...).
     */
    protected T absoluteRoot = null;

    protected T visibleRoot;

    protected EventListenerList listenerList = new EventListenerList();

    private static final int CHANGED = 0;

    private static final int INSERTED = 1;

    private static final int REMOVED = 2;

    private static final int STRUCTURE_CHANGED = 3;

    public MyAbstractTreeTableModel(UploadPolicy uploadPolicy, T root) {
        this.uploadPolicy = uploadPolicy;
        this.absoluteRoot = root;
        this.visibleRoot = root;
        this.absoluteRoot.setTreeModel(this);
        this.visibleRoot.setTreeModel(this);
    }

    /**
     * @return the tree
     */
    public MyTreeTableCellRenderer getTree() {
        return tree;
    }

    /**
     * @param tree the tree to set
     */
    public void setTree(MyTreeTableCellRenderer tree) {
        this.tree = tree;
    }

    public T getAbsoluteRoot() {
        return this.absoluteRoot;
    }

    /** @see MyTreeTableModel#getRoot() */
    public T getRoot() {
        return visibleRoot;
    }

    /**
     * @see MyTreeTableModel#setRoot(MyTreeNode)
     * @throws IllegalArgumentException If this root is not valid.
     */
    public synchronized void setRoot(T root) {
        this.uploadPolicy.displayInfo("Setting visible Root to file " + root.toString());
        this.visibleRoot = root;
        reload();
    }

    /** @see MyTreeTableModel#remove(MyTreeNode) */
    public synchronized void remove(T item) {
        remove(item, true);
    }

    /** @see MyTreeTableModel#remove(MyTreeNode) */
    public synchronized void removeAndClean(T item) {
        removeAndClean(item, true);
    }

    /**
     * Actual implementation of {@link #remove(MyTreeNode)}
     * 
     * @param item The item to remove
     * @param callReloadAfterRemoval true if the {@link #reload()} should be called after removal, false otherwise.
     * @see MyTreeTableModel#remove(MyTreeNode)
     */
    @SuppressWarnings("unchecked")
    synchronized void remove(T item, boolean callReloadAfterRemoval) {
        if (item == absoluteRoot) {
            throw new IllegalArgumentException("The absoluteRoot may not be removed");
        }
        if (item == visibleRoot) {
            setRoot((T) visibleRoot.getParent());
        }

        FolderNode parent = (FolderNode) item.getParent();
        if (parent != null) {
            // Actually executes the removal. This removes the node, and detach all of its descendants.
            parent.removeChild(item);
            // If asked for, we indicates that the structure has changed.
            if (callReloadAfterRemoval) {
                reload();
            }
        }
    }

    /**
     * Actual implementation of {@link #removeAndClean(MyTreeNode)}
     * 
     * @param item The item to remove
     * @param callReloadAfterRemoval true if the {@link #reload()} should be called after removal, false otherwise.
     * @see wjhk.jupload2.gui.filepanel.treeview.MyTreeTableModel#removeAndClean(wjhk.jupload2.gui.filepanel.treeview.MyTreeNode)
     */
    @SuppressWarnings("unchecked")
    synchronized void removeAndClean(T item, boolean callReloadAfterRemoval) {
        if (item == absoluteRoot) {
            throw new IllegalArgumentException("The absoluteRoot may not be removed");
        }
        if (item == visibleRoot) {
            setRoot((T) visibleRoot.getParent());
        }

        T parentNode = (T) item.getParent();

        // First step: actually remove the node
        remove(item, false);

        // Second step: remove the parent node, if it had no other child.
        if (parentNode.getChildCount() == 0) {
            // No reload during recursion
            removeAndClean(parentNode, false);
        } else if (callReloadAfterRemoval) {
            reload();
        }
    }

    /** @see MyTreeTableModel#getTreePath(MyTreeNode) */
    @SuppressWarnings("unchecked")
    public TreePath getTreePath(T item) {
        if (item == null) {
            // This method may be called with a null Node. In this case, we return .. an empty TreePath
            return null;
        } else if (item == this.absoluteRoot) {
            return new TreePath(this.absoluteRoot);
        } else if (item.getParent() == null) {
            throw new IllegalArgumentException("Root not found for node " + item);
        } else {
            return getTreePath((T) item.getParent()).pathByAddingChild(item);
        }
    }

    public void addTreeModelListener(TreeModelListener l) {
        listenerList.add(TreeModelListener.class, l);
    }

    public void removeTreeModelListener(TreeModelListener l) {
        listenerList.remove(TreeModelListener.class, l);
    }

    private void fireTreeNode(int changeType, Object source, TreePath path, int[] childIndices, T[] children) {
        Object[] listeners = listenerList.getListenerList();
        TreeModelEvent e = new TreeModelEvent(source, path, childIndices, children);
        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == TreeModelListener.class) {
                switch (changeType) {
                    case CHANGED:
                        ((TreeModelListener) listeners[i + 1]).treeNodesChanged(e);
                        break;
                    case INSERTED:
                        ((TreeModelListener) listeners[i + 1]).treeNodesInserted(e);
                        break;
                    case REMOVED:
                        ((TreeModelListener) listeners[i + 1]).treeNodesRemoved(e);
                        break;
                    case STRUCTURE_CHANGED:
                        ((TreeModelListener) listeners[i + 1]).treeStructureChanged(e);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    /** @see wjhk.jupload2.gui.filepanel.treeview.MyTreeTableModel#cleanHierarchy() */
    synchronized public boolean cleanHierarchy() {
        return cleanHierarchy(absoluteRoot, true);
    }

    /**
     * Cleans the hierarchy behind a given node. It's actually the recursive implementation for
     * {@link wjhk.jupload2.gui.filepanel.treeview.MyTreeTableModel#cleanHierarchy()}
     * 
     * @return true if at least one node was removed, due to cleaning. false if no cleaning was needed.
     */
    synchronized public boolean cleanHierarchy(T node) {
        return cleanHierarchy(node, true);
    }

    /**
     * Cleans the hierarchy behind a given node. It's actually the recursive implementation for
     * {@link wjhk.jupload2.gui.filepanel.treeview.MyTreeTableModel#cleanHierarchy()}
     * 
     * @param node The node where cleaning starts. This node will not be removed.
     * @param callReloadAfterRemoval true if the {@link #reload()} should be called after removal, false otherwise.
     * @return true if at least one node was removed, due to cleaning. false if no cleaning was needed.
     */
    @SuppressWarnings("unchecked")
    synchronized private boolean cleanHierarchy(T node, boolean callReloadAfterRemoval) {
        boolean ret = false;
        if (node != null) {
            if (node.getChildren().size() > 0) {
                // To avoid that a ConcurrentModificationException is thrown, we must not use the list. Here is another
                // way to loop into it, while the list size can diminish (due to node removal during recursion)
                List<T> children = new ArrayList<T>();
                for (MyTreeNode child : node.getChildren()) {
                    children.add((T) child);
                }

                for (T child : children) {
                    if (cleanHierarchy(child, false)) {
                        ret = true;
                    }
                    // If we've a non leaf folder (typically a FolderNode), with no children, we remove it.
                    if (!child.isLeaf() && child.getChildCount() == 0) {
                        node.removeChild(child);
                        ret = true;
                    }
                }// for
            }// if (node.getChildren().size() > 0)
        }// if (node != null)

        if (ret && callReloadAfterRemoval) {
            reload();
        }
        return ret;
    }

    /** @see MyTreeTableModel#reload() */
    public synchronized void reload() {
        reload(visibleRoot);
    }

    /** @see MyTreeTableModel#reload(MyTreeNode) */
    @SuppressWarnings("unchecked")
    public synchronized void reload(T node) {
        //
        int n = getChildCount(node);
        int[] childIdx = new int[n];
        T[] children = (T[]) (T[]) Array.newInstance(MyTreeNode.class, n);

        for (int i = 0; i < n; i++) {
            childIdx[i] = i;
            children[i] = getChild(node, i);
        }

        fireTreeStructureChanged(this, getPathToRoot(node), childIdx, (T[]) children);
    }

    /**
     * Builds the parents of node up to and including the root node, where the original node is the last element in the
     * returned array. The length of the returned array gives the node's depth in the tree.
     * 
     * @param node - the TreeNode to get the path for
     * @return TreeNode[] - the path from node to the root
     * @throws IllegalArgumentException If the node has not visibleRoot as a ancestror.
     */
    private TreePath getPathToRoot(MyTreeNode node) {
        if (node == visibleRoot) {
            return new TreePath(visibleRoot);
        } else if (node == absoluteRoot) {
            throw new IllegalArgumentException("The visibleRoot is not an ancestror of the given node");
        } else {
            MyTreeNode parent = (MyTreeNode) node.getParent();
            if (parent == null) {
                return null;
            } else {
                return getPathToRoot(parent).pathByAddingChild(node);
            }
        }
    }

    /** @see MyTreeTableModel#fireTreeNodesChanged(MyTreeNode, MyTreeNode[], int[], MyTreeNode[]) */
    public void fireTreeNodesChanged(Object source, TreePath path, int[] childIndices, T[] children) {
        fireTreeNode(CHANGED, source, path, childIndices, children);
    }

    /** @see MyTreeTableModel#fireTreeNodesInserted(MyTreeNode, MyTreeNode[], int[], MyTreeNode[]) */
    public void fireTreeNodesInserted(Object source, TreePath path, int[] childIndices, T[] children) {
        fireTreeNode(INSERTED, source, path, childIndices, children);
    }

    /** @see MyTreeTableModel#fireTreeNodesRemoved(MyTreeNode, MyTreeNode[], int[], MyTreeNode[]) */
    public void fireTreeNodesRemoved(Object source, TreePath path, int[] childIndices, T[] children) {
        fireTreeNode(REMOVED, source, path, childIndices, children);
    }

    /** @see MyTreeTableModel#fireTreeStructureChanged(MyTreeNode, MyTreeNode[], int[], MyTreeNode[]) */
    public void fireTreeStructureChanged(Object source, TreePath path, int[] childIndices, T[] children) {
        fireTreeNode(STRUCTURE_CHANGED, source, path, childIndices, children);
    }

    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Implementation of the TreeModel interface: can't override these methods by narrowing Object to
    // MyHierarchicalFileData. So we must 'manually' manage the cast from T to MyHierarchicalFileData.
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /** @see TreeModel#getChild(Object, int) */
    @SuppressWarnings("unchecked")
    public final T getChild(Object parent, int index) {
        return (T) ((T) parent).getChild(index);
    }

    /** @see TreeModel#getChildCount(Object) */
    @SuppressWarnings("unchecked")
    public final int getChildCount(Object child) {
        return ((T) child).getChildCount();
    }

    /** @see TreeModel#isLeaf(Object) */
    @SuppressWarnings("unchecked")
    public final boolean isLeaf(Object node) {
        return ((T) node).isLeaf();
    }

    /**
     * This is normally not called
     * 
     * @see TreeModel#valueForPathChanged(TreePath, Object)
     */
    public final void valueForPathChanged(TreePath path, Object newValue) {
        uploadPolicy.displayErr("The method MyAbstractTreeTableModel.valueForPathChanged should not be called");
    }

    /**
     * This is normally not called
     * 
     * @see TreeModel#getIndexOfChild(Object, Object)
     */
    @SuppressWarnings("unchecked")
    public final int getIndexOfChild(Object parent, Object child) {
        return ((T) parent).getChildren().indexOf((T) child);
    }

    public abstract Object getValueAt(T nodeForRow, int column);

}