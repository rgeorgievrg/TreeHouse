package wjhk.jupload2.gui.filepanel.treeview;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.util.EventObject;

import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.table.TableCellEditor;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * This class is a generic class. It has not been adapted for JUpload. It's directly taken from Jörn Hameister tutorial<BR/>
 * In order to allow the unfolding of the tree one, needs a AbstractCellEditor . That's why you put a class
 * MyTreeTableCellEditor to the AbstractCellEditor expanded and the TableCellEditor implemented interface. The only
 * function of the class MyTreeTableCellEditor is forwarding a double-click on the tree. In the method isCellEditable is
 * checked whether the first column ( column1 ) was clicked. If this is the case, a double click is on the tree forward,
 * so that the ExpansionListener can respond.
 * 
 * @author Jörn Hameister
 */
public class MyTreeTableCellEditor extends AbstractCellEditor implements TableCellEditor {

    private static final long serialVersionUID = 1L;

    private JTree tree;

    private JTable table;

    public MyTreeTableCellEditor(JTree tree, JTable table) {
        this.tree = tree;
        this.table = table;
    }

    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int r, int c) {
        return tree;
    }

    public boolean isCellEditable(EventObject e) {
        if (e instanceof MouseEvent) {
            int colunm1 = 0;
            MouseEvent me = (MouseEvent) e;
            int doubleClick = 2;
            MouseEvent newME = new MouseEvent(tree, me.getID(), me.getWhen(), me.getModifiers(), me.getX()
                    - table.getCellRect(0, colunm1, true).x, me.getY(), doubleClick, me.isPopupTrigger());
            tree.dispatchEvent(newME);
        }
        return false;
    }

    // @Override
    public Object getCellEditorValue() {
        return null;
    }

}