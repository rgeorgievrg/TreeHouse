package wjhk.jupload2.gui.filepanel.treeview;

import java.io.File;
import java.util.Date;

import javax.swing.table.TableModel;
import javax.swing.tree.TreePath;

import wjhk.jupload2.exception.JUploadExceptionStopAddingFiles;
import wjhk.jupload2.gui.filepanel.FilePanel;
import wjhk.jupload2.gui.filepanel.FilePanelFlatDataModel2;
import wjhk.jupload2.policies.UploadPolicy;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * In the class MyDataModel the concrete data model view is defined. Ie, the columns are defined including data type.
 * The class also contains the unimplemented methods of the interface TreeModel . It should be noted the method
 * isCellEditable . This has the value true return so that the Listener on a treeExpanded or treeCollapsed can respond.
 * One could in this method only for the first column ( column ) the value true and otherwise return the value false .
 * 
 * @author Jörn Hameister
 */
public class FileDataTreeViewModel extends MyAbstractTreeTableModel<TreeFileDataNode> {

    /**
     * The uploadPolicy contains all current parameter, including the FileDataParam
     */
    UploadPolicy uploadPolicy = null;

    /**
     * The column names, as displayed on the applet. They are not real final values, as they are translated: we need to
     * have an uploadPolicy for this translation, and the uploadPolicy is 'given' to the constructor.
     */
    final static String COL_NAME = "colName";

    final static String COL_SIZE = "colSize";

    final static String COL_DIRECTORY = "colDirectory";

    final static String COL_MODIFIED = "colModified";

    /** The localized column name, for the file name */
    String colName = null;

    /** The localized column name, for the file size */
    String colSize = null;

    /** The localized column name, for the file directory */
    String colDirectory = null;

    /** The localized column name, for the file last modification date */
    String colModified = null;

    String[] columnNames = null;

    /**
     * This array indicates, for each column, the percentage of the available width it should use. It's initialized in
     * the constructor of this class.
     * 
     * @see #getColumnSize(int)
     */
    int[] columnSizePercentage = null;

    /**
     * Indicates whether each column is editable or not. Only the check box should be editable.
     */
    boolean[] columnEditable = null;

    Class<?> columnClasses[] = null;

    public FileDataTreeViewModel(UploadPolicy uploadPolicy, FilePanelFlatDataModel2 flatModel) {
        // The models are unknown now. They will be set later.
        super(uploadPolicy, new RootNode(uploadPolicy, null, flatModel));

        this.uploadPolicy = uploadPolicy;

        // Initialization for column name
        colName = this.uploadPolicy.getLocalizedString(COL_NAME);
        colSize = this.uploadPolicy.getLocalizedString(COL_SIZE);
        colDirectory = this.uploadPolicy.getLocalizedString(COL_DIRECTORY);
        colModified = this.uploadPolicy.getLocalizedString(COL_MODIFIED);
        this.columnNames = new String[] {
                colName, colSize, colDirectory, colModified, ""
        };

        // Initial size (before percentage) was: 150, 75, 199, 130, 75
        this.columnSizePercentage = new int[] {
                50, 17, 15, 15, 3
        };

        this.columnClasses = new Class[] {
                MyTreeTableModel.class, Long.class, String.class, Date.class, Boolean.class
        };

        // Initial size (before percentage) was: 150, 75, 199, 130, 75
        this.columnEditable = new boolean[] {
                true, false, false, false, true
        };
    }

    /** {@inheritDoc} */
    public int getColumnCount() {
        return columnNames.length;
    }

    /** {@inheritDoc} */
    public String getColumnName(int column) {
        return columnNames[column];
    }

    /** {@inheritDoc} */
    public int getColumnSizePercentage(int col) {
        return this.columnSizePercentage[col];
    }

    /** {@inheritDoc} */
    public Class<?> getColumnClass(int column) {
        return columnClasses[column];
    }

    /** {@inheritDoc} */
    public Object getValueAt(TreeFileDataNode node, int column) {
        if (node != null) {
            String columnName = getColumnName(column);
            // Don't know if it will be useful, but the switch below allows the
            // column to be in any order.
            if (columnName.equals(colName)) {
                return node.getFileName();
            } else if (columnName.equals(colSize)) {
                return Long.valueOf(node.getFileLength());
            } else if (columnName.equals(colDirectory)) {
                return node.getDirectory();
            } else if (columnName.equals(colModified)) {
                return node.getLastModified();
            } else if (columnName.equals("")) {
                return node.getUploadFlag();
            } else {
                this.uploadPolicy.displayErr("Unknown column in " + this.getClass().getName() + ": " + columnName);
                return null;
            }
        } else {
            return null;
        }
    }

    /** @see TableModel#isCellEditable(int, int) */
    public boolean isCellEditable(TreeFileDataNode node, int column) {
        return columnEditable[column];
    }

    /** @see TableModel#setValueAt(Object, int, int) */
    public void setValueAt(Object aValue, TreeFileDataNode node, int col) {
        if (!columnEditable[col]) {
            this.uploadPolicy.displayWarn(this.getClass().getName() + ".setValueAt: no action");
        } else {
            if (!(aValue instanceof Boolean)) {
                this.uploadPolicy.displayErr("Internal error in " + this.getClass().getName()
                        + ": aValue should be a Boolean but is a " + aValue.getClass().getName());
            } else {
                node.setUploadFlag((Boolean) aValue);
                uploadPolicy.displayDebug("uploadFlag set to " + (Boolean) aValue + " for file " + node.getAbsolutePath(), 10);
            }
        }
    }

    /**
     * Returns the {@link TreePath} for the given {@link File}. This TreePath is basically the array of
     * {@link TreeFileDataNode}, representing the given file. the root path if the filename for the {@link RootNode},
     * that is: the empty String: ""
     * 
     * @param fileRoot The File we want the path for. It may be the root, a folder, leaf...
     * @return The TreePath for this file, or null if this file doesn't exist in the existing hierarchy. public TreePath
     *         getTreePath(TreeFileDataNode fileData) { TreeFileDataNode parent = (TreeFileDataNode)
     *         fileData.getParent(); if (parent == null) { TreeFileDataNode[] path = (TreeFileDataNode[])
     *         (Array.newInstance(TreeFileDataNode.class, 2)); path[0] = absoluteRoot; path[1] = ((FolderNode)
     *         absoluteRoot).getChild(fileData.getFileName()); return new TreePath(path); } else { TreePath
     *         treePathParent = getTreePath(parent); if (treePathParent == null) { // The parent is not in the file
     *         hierarchy, so this file is not either. return null; } else { FolderNode folderNodeParent = (FolderNode)
     *         treePathParent.getLastPathComponent(); TreeFileDataNode tfdn =
     *         folderNodeParent.getChild(fileData.getFileName()); if (tfdn == null) { // This file doesn't exist in the
     *         hierarchy. return null; } else { return treePathParent.pathByAddingChild(tfdn); } } } }
     */

    /**
     * Returns the {@link TreePath} for the given {@link File}. This TreePath is basically the array of
     * {@link TreeFileDataNode}, representing the given file. the root path if the filename for the {@link RootNode},
     * that is: the empty String: ""
     * 
     * @param fileRoot The File we want the path for. It may be the root, a folder, leaf... If the given file is null,
     *            the returned {@link TreePath} is a one level {@link TreePath}, containing only the absolute root of
     *            the tree view.
     * @param createIntermediateNode If true, all missing intermediate nodes are created. If false, no node are created.
     *            In this last case, the returned {@link TreePath} is null, if one or mode nodes are missing.
     * @return The TreePath for this file, or null if this file doesn't exist in the existing hierarchy.
     * @throws JUploadExceptionStopAddingFiles
     */
    public TreePath getTreePathFromFile(File file, boolean createIntermediateNode)
            throws JUploadExceptionStopAddingFiles {
        if (this.uploadPolicy.getFileListViewMode() != FilePanel.FileListViewMode.FLAT
                && this.uploadPolicy.getFileListViewMode() != FilePanel.FileListViewMode.TREE_VIEW) {
            throw new IllegalStateException(this.getClass().getName()
                    + ".getTreePathFromFile(File) may not be called when the ListViewMode is in "
                    + this.uploadPolicy.getFileListViewMode() + " mode");
        }
        if (file == null) {
            return new TreePath(absoluteRoot);
        } else {
            TreePath parentTreePath = getTreePathFromFile(file.getParentFile(), createIntermediateNode);
            if (parentTreePath == null) {
                // At least one node is missing. We can't build the TreePath
                return null;
            } else {
                // The parent TreePath should finish by a folder ... as it's our parent !
                FolderNode parentNode = (FolderNode) parentTreePath.getLastPathComponent();
                TreeFileDataNode node = parentNode.getChild(file);

                // If file is not a child of the node for the parent file, we may have to create a new Node.
                if (node == null && createIntermediateNode) {
                    node = parentNode.addChild(file);
                }

                // If there is no node for our file ... there is no valid TreePath
                if (node == null) {
                    return null;
                } else {
                    return parentTreePath.pathByAddingChild(node);
                }
            }/*
              * File parent = file.getParentFile(); if (parent == null) { TreeFileDataNode[] path = (TreeFileDataNode[])
              * (Array.newInstance(TreeFileDataNode.class, 2)); path[0] = absoluteRoot; path[1] = ((FolderNode)
              * absoluteRoot).getChild(file); // if the root doesn't return new TreePath(path); } else { TreePath
              * treePathParent = getTreePathFromFile(parent, createIntermediateNode); if (treePathParent == null) { //
              * The parent is not in the file hierarchy, so this file is not either. return null; } else { FolderNode
              * folderNodeParent = (FolderNode) treePathParent.getLastPathComponent(); TreeFileDataNode tfdn =
              * folderNodeParent.getChild(file); if (tfdn == null) { // This file doesn't exist in the hierarchy. return
              * null; } else { return treePathParent.pathByAddingChild(tfdn); } } }
              */
        }// if (file == null)
    }

    /**
     * Returns the node corresponding to the given treePath, or null if this node is'nt found, when crawling the
     * hierarchy behind {@link #absoluteRoot}.
     * 
     * @param treePath A {@link TreePath} made of String. If it's made of String, each represents a filename. If it's a
     *            {@link TreePath} made of TreeFileDataNode, this method works, but it's much quicker to just use
     *            {@link TreePath#getLastPathComponent()} instead of this method.
     * @return TreeFileDataNode getNode(TreePath treePath) { TreePath parent = treePath.getParentPath(); if (parent ==
     *         null) { return absoluteRoot; } else { TreeFileDataNode parentNode = getNode(parent); return
     *         (TreeFileDataNode) parentNode.getChild((String) treePath.getLastPathComponent()); } }
     */

    /**
     * This method returns
     * 
     * @param file
     * @return
     * @throws JUploadExceptionStopAddingFiles public FolderNode getFolderNodeForNewFile(File file) throws
     *             JUploadExceptionStopAddingFiles { return getFolderNodeForNewFile(file.getParentFile(), null); }
     */

    /**
     * This method searches in the hierarchy of files and folder to upload, the node which contains this file. If this
     * node doesn't exist, it is first created and attached into the hierarchy.
     * 
     * @param o A File or Folder. If o is a file, it will just be added. If o is a folder, it will be added, including
     *            all its content (child, grand-child...)
     * @return The number of files added to the hierarchy. Folders are not counted.
     * @throws JUploadExceptionStopAddingFiles When an exception occurs
     * @throws NullPointerException When o is null
     * @throws IllegalArgumentException When o is not a {@link File}
     * @see MyAbstractTreeTableModel
     */
    public int attachObject(Object o) throws NullPointerException, IllegalArgumentException,
            JUploadExceptionStopAddingFiles {
        if (o == null) {
            throw new NullPointerException(this.getClass().getName() + " has been called with a null parameter");
        } else if (!(o instanceof File)) {
            throw new IllegalArgumentException(this.getClass().getName() + " has been called with a "
                    + o.getClass().getName() + ". It must be a File");
        }
        File file = (File) o;

        FolderNode parentNode = null;
        switch (uploadPolicy.getFileListViewMode()) {
            case FLAT:
            case TREE_VIEW:
                // We're mapped to the file system, we need to find the parent for this file.
                if (file.getParentFile() != null) {
                    parentNode = (FolderNode) getTreePathFromFile(file.getParentFile(), true).getLastPathComponent();
                } else {
                    parentNode = (FolderNode) absoluteRoot;
                }
                break;
            case INDEPENDENT_TREE_VIEW:
                // Otherwise, it's just a new child of the root.
                parentNode = (FolderNode) absoluteRoot;
        }

        if (parentNode == null) {
            throw new IllegalArgumentException("Root not found for file " + file.getAbsolutePath());
        }

        return parentNode.addChildAndDescendants(file);
    }

    /** {@inheritDoc} */
    public TreePath getTreePathForObject(Object o, boolean createIntermediateNode) {
        if (o != null && !(o instanceof File)) {
            throw new IllegalArgumentException(this.getClass().getName() + " has been called with a "
                    + o.getClass().getName() + ". It must be a File");
        }
        try {
            return getTreePathFromFile((File) o, createIntermediateNode);
        } catch (JUploadExceptionStopAddingFiles e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

}
