package wjhk.jupload2.gui.filepanel.treeview;

import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.tree.DefaultTreeSelectionModel;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * Since the TreeTable composed of a JTree component and a JTable component, it must be ensured that in the selection of
 * the tree or table always has a continuous line is highlighted. To ensure that you create a class
 * MyTreeTableSelectionModel that extends the DefaultTreeSelectionModel. This selection model is later assigned to the
 * JTree and JTable to.
 * 
 * @author Jörn Hameister
 */
public class MyTreeTableSelectionModel extends DefaultTreeSelectionModel {

    private static final long serialVersionUID = 1L;

    public MyTreeTableSelectionModel() {
        super();

        getListSelectionModel().addListSelectionListener(new ListSelectionListener() {
            // @Override
            public void valueChanged(ListSelectionEvent e) {
                System.out.print("[DEBUG] ListSelectionEvent: " + e + "\n");
            }
        });
    }

    ListSelectionModel getListSelectionModel() {
        return listSelectionModel;
    }
}