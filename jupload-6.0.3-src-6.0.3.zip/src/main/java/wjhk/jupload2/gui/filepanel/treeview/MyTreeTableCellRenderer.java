package wjhk.jupload2.gui.filepanel.treeview;

import java.awt.Component;
import java.awt.Graphics;

import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.TreeModel;

/**
 * This code is taken from the tutorial written by Jörn Hameister, <A
 * HREF="http://www.hameister.org/JavaSwingTreeTable.html">available here</A>.<BR/>
 * <BR/>
 * <UL>
 * <LI>Call to tree.setVisibleRoot(false) pour masquer la racine.</LI>
 * <UL>
 * <BR/>
 * The last thing the JTree and JTable which must now be created. The Tree component MyTreeTableCellRenderer inherits
 * from JTree and implements the TableCellRenderer interface. This class ensures that the row heights of Tree and Table
 * are the same and are set correctly in the selection of the background colors. It also ensures that the elements of
 * the tree are indented correctly depending on the level.
 * 
 * @author Jörn Hameister
 */
public class MyTreeTableCellRenderer extends JTree implements TableCellRenderer {

    private static final long serialVersionUID = 1L;

    /** Die letzte Zeile, die gerendert wurde. */
    protected int visibleRow;

    private MyTreeTable treeTable;

    public MyTreeTableCellRenderer(MyTreeTable treeTable, TreeModel model) {
        super(model);
        this.treeTable = treeTable;

        // Setzen der Zeilenhoehe fuer die JTable
        // Muss explizit aufgerufen werden, weil treeTable noch
        // null ist, wenn super(model) setRowHeight aufruft!
        setRowHeight(getRowHeight());
        
        setRootVisible(false);
        setScrollsOnExpand(true);
        setShowsRootHandles(true);
    }

    /**
     * Tree und Table muessen die gleiche Hoehe haben.
     */
    public void setRowHeight(int rowHeight) {
        if (rowHeight > 0) {
            super.setRowHeight(rowHeight);
            if (treeTable != null && treeTable.getRowHeight() != rowHeight) {
                treeTable.setRowHeight(getRowHeight());
            }
        }
    }

    /**
     * Tree muss die gleiche Hoehe haben wie Table.
     */
    public void setBounds(int x, int y, int w, int h) {
        super.setBounds(x, 0, w, treeTable.getHeight());
    }

    /**
     * Sorgt fuer die Einrueckung der Ordner.
     */
    public void paint(Graphics g) {
        g.translate(0, -visibleRow * getRowHeight());

        super.paint(g);
    }

    /**
     * Liefert den Renderer mit der passenden Hintergrundfarbe zurueck.
     */
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
            int row, int column) {
        if (isSelected)
            setBackground(table.getSelectionBackground());
        else
            setBackground(table.getBackground());

        visibleRow = row;
        return this;
    }
}