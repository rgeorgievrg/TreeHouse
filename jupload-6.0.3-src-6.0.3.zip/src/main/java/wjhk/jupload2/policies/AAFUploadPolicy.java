package wjhk.jupload2.policies;

import java.io.File;

import wjhk.jupload2.context.JUploadContext;
import wjhk.jupload2.exception.JUploadException;

public class AAFUploadPolicy extends DefaultUploadPolicy {

    // To be removed
    // private final JUploadContext juploadContext;

    public AAFUploadPolicy(JUploadContext juploadContext) throws JUploadException {
        super(juploadContext);
        // Do not use the local juploadContext.
    }

    @Override
    public void start() {
        super.start();

        File[] files = new File[1];
        files[0] = new File("C:\\Temp\\Rapport.xls");
        getContext().getUploadPanel().getFilePanel().addFiles(files);

    }
}