
This folder contains all static files used by the various tests case (images for the picture mode, specific conf files...).

This folder and its content are not added to the applet jar file. 

