//
// $Id$
//
// jupload - A file upload applet.
//
// Copyright 2015 The JUpload Team
//
// Created: 8 févr. 2015
// Creator: etienne_sf
// Last modified: $Date$
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

package wjhk.jupload2.gui.filepanel;

import static org.junit.Assert.*;

import java.awt.Point;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import wjhk.jupload2.filedata.DefaultFileData;
import wjhk.jupload2.filedata.FileData;
import wjhk.jupload2.gui.filepanel.treeview.FileDataNode;
import wjhk.jupload2.gui.filepanel.treeview.FileDataTreeViewModel;
import wjhk.jupload2.gui.filepanel.treeview.FolderNode;
import wjhk.jupload2.gui.filepanel.treeview.RootNode;
import wjhk.jupload2.gui.filepanel.treeview.TreeFileDataNode;
import wjhk.jupload2.upload.AbstractJUploadTestHelper;

/**
 * @author etienne_sf
 */
public class FilePanelTableImpTest extends AbstractJUploadTestHelper {

    FilePanelTableImp filePanelTableImp = null;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        filePanelTableImp = new FilePanelTableImp(juploadPanel, uploadPolicy);
        this.fileDataTreeViewModel = (FileDataTreeViewModel) ((FileDataTreeViewModel) this.filePanelTableImp.treeModel);
        assertEquals("check root",
                (TreeFileDataNode) ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot(),
                (TreeFileDataNode) this.fileDataTreeViewModel.getRoot());

        File[] files = new File[2];
        files[0] = getTestFile("files/level1/level2");
        files[1] = getTestFile("files/level1/level22");
        filePanelTableImp.addFiles(files);

        // For this test, we need both table to be 'visible'. So that they get updated when the file list changes.
        // filePanelTableImp.flatTable.setVisible(true);
        // filePanelTableImp.treeTable.setVisible(true);
    }

    @Test
    public void testConstructor() {
        assertNotNull("flatTable", filePanelTableImp.flatTable);
        assertNotNull("flatModel", filePanelTableImp.flatModel);
        assertNotNull("treeModel", ((FileDataTreeViewModel) this.filePanelTableImp.treeModel));
        assertNotNull("treeTable", filePanelTableImp.treeTable);
        assertNotNull("root", ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot());
    }

    /**
     * Test method for {@link wjhk.jupload2.gui.filepanel.FilePanelTableImp#addFiles(java.io.File[], java.io.File)}.
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testAddFiles() {
        // Check of the original call to addFiles
        assertEquals("before 1", 3, filePanelTableImp.getFiles().size());
        assertEquals("before 2", 3, filePanelTableImp.getFilesLength());
        // The number of children for the absolute root depends on the location of the project on the local file system
        assertEquals("filePanelTableImp.addFiles (treeModel.getAbsoluteRoot())",
                nbSubfoldersForSrcTestResourcesFiles + 8, ((FileDataTreeViewModel) this.filePanelTableImp.treeModel)
                        .getAbsoluteRoot().getTotalChildCount());
        // The number of children for the visible root is an absolute numbre (doesn't depend on the location of the
        // project on the local file system)
        assertEquals("filePanelTableImp.addFiles (visible root)", 7,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getRoot().getTotalChildCount());
        TreeFileDataNode tfdn = ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot();
        assertTrue("tfdn instanceof RootNode", tfdn instanceof RootNode);
        // The tree root must the good one (not the absolute one)
        assertEquals("treeModel.getRoot().getFileName()", "level1",
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getRoot().getFileName());
        // We go from RootNode to files/level1
        for (int i = 0; i <= nbSubfoldersForSrcTestResourcesFiles; i += 1) {
            assertEquals("One child for " + tfdn.getFileName(), 1, tfdn.getChildCount());
            // For folder other than the FS root (/ for unix, and C:\ for windows, for instance), we check that the
            // filenames doesn't contain a file separator
            if (i > 1) {
                assertFalse("No file separator 1 " + tfdn.getFileName(), tfdn.getFileName().contains("/"));
                assertFalse("No file separator 2 " + tfdn.getFileName(), tfdn.getFileName().contains("\\"));
            }
            tfdn = (TreeFileDataNode) tfdn.getChildren().get(0);
            assertTrue("FolderNode for " + tfdn.getFileName(), tfdn instanceof FolderNode);
        }// for
         // Let's test the specific loading of the use case. Two folders have been added: files/level1/level2 and
         // files/level1/level22

        // Check of files/level1
        assertEquals("Two children for " + tfdn.getFileName(), 2, tfdn.getChildCount());
        for (FolderNode sub : (List<FolderNode>) (List<?>) tfdn.getChildren()) {
            assertFalse("No file separator 1 " + sub.getFileName(), sub.getFileName().contains("/"));
            assertFalse("No file separator 2 " + sub.getFileName(), sub.getFileName().contains("\\"));
        }
        // Check of files/level1/level2
        TreeFileDataNode tfdnLevel2 = (TreeFileDataNode) tfdn.getChildren().get(0);
        checkTreeFileDataNode(tfdnLevel2, FolderNode.class, "level2", 2, 4);
        checkTreeFileDataNode((TreeFileDataNode) tfdnLevel2.getChildren().get(0), FolderNode.class, "level3", 1, 1);
        checkTreeFileDataNode((TreeFileDataNode) tfdnLevel2.getChildren().get(0).getChildren().get(0),
                FileDataNode.class, "ATestFile3.txt", 0, 0);
        checkTreeFileDataNode((TreeFileDataNode) tfdnLevel2.getChildren().get(1), FolderNode.class, "level33", 1, 1);
        checkTreeFileDataNode((TreeFileDataNode) tfdnLevel2.getChildren().get(1).getChildren().get(0),
                FileDataNode.class, "ATestFile33.txt", 0, 0);
        // Check of files/level1/level22
        TreeFileDataNode tfdnLevel22 = (TreeFileDataNode) tfdn.getChildren().get(1);
        checkTreeFileDataNode(tfdnLevel22, FolderNode.class, "level22", 1, 1);
        checkTreeFileDataNode((TreeFileDataNode) tfdnLevel22.getChildren().get(0), FileDataNode.class,
                "ATestFile22.txt", 0, 0);

        // go, go, go...
        File[] files = new File[2];
        files[0] = getTestFile("files/level11");
        files[1] = getTestFile("files");
        filePanelTableImp.addFiles(files);

        // Checks
        assertEquals("after 1", 18, filePanelTableImp.getFiles().size());
        assertEquals("after 2", 18, filePanelTableImp.getFilesLength());
        // The number of children for the absolute root depends on the location of the project on the local file system
        assertEquals("after 3 (treeModel.getAbsoluteRoot())", nbSubfoldersForSrcTestResourcesFiles + 25,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot().getTotalChildCount());
        // The number of children for the visible root is an absolute numbre (doesn't depend on the location of the
        // project on the local file system)
        assertEquals("after 3 (treeview root)", 25, ((FileDataTreeViewModel) this.filePanelTableImp.treeModel)
                .getRoot().getTotalChildCount());

        // The tree root must the good one (not the absolute one)
        assertEquals("treeModel.getRoot().getFileName()", "files",
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getRoot().getFileName());
    }

    private void checkTreeFileDataNode(TreeFileDataNode tfdn, Class<?> clazz, String filename, int childCount,
            int totalChildCount) {
        assertTrue("FolderNode for " + tfdn.getFileName(), clazz.isInstance(tfdn));
        assertEquals("getFileName for " + tfdn.getFileName(), filename, tfdn.getFileName());
        assertEquals("getChildCount for " + tfdn.getFileName(), childCount, tfdn.getChildCount());
        assertEquals("getTotalChildCount for " + tfdn.getFileName(), totalChildCount, tfdn.getTotalChildCount());
    }

    /**
     * Test method for {@link wjhk.jupload2.gui.filepanel.FilePanelTableImp#removeSelected()}.
     */
    @Test
    public void testRemoveSelected() {
        // Preparation
        assertEquals("before 2", 3, filePanelTableImp.getFilesLength());
        // check on absolute root
        assertEquals("before 3", nbSubfoldersForSrcTestResourcesFiles + 8,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot().getTotalChildCount());
        // check on visible root
        assertEquals("filePanelTableImp.addFiles (visible root)", 7,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getRoot().getTotalChildCount());
        filePanelTableImp.flatTable.setRowSelectionInterval(1, 2);

        // go, go, go...
        filePanelTableImp.removeSelected();

        // Checks
        assertEquals("after 2", 1, filePanelTableImp.getFilesLength());
        // check on absolute root
        assertEquals("after 3", nbSubfoldersForSrcTestResourcesFiles + 4,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot().getTotalChildCount());
        // check on visible root
        assertEquals("filePanelTableImp.addFiles (visible root)", 3,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getRoot().getTotalChildCount());
    }

    /**
     * Test method for {@link wjhk.jupload2.gui.filepanel.FilePanelTableImp#remove(wjhk.jupload2.filedata.FileData)}.
     */
    @Test
    public void testRemoveFileData() {
        // Preparation
        List<FileData> rows = new ArrayList<FileData>(filePanelTableImp.flatModel.getRowCount());
        for (int i = 0; i < filePanelTableImp.flatModel.getRowCount(); i += 1) {
            rows.add(filePanelTableImp.flatModel.getFileDataAt(i));
        }
        assertEquals("before (flat)", 3, rows.size());
        assertEquals("before (tree)", nbSubfoldersForSrcTestResourcesFiles + 8,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot().getTotalChildCount());
        // A useless selection. Should not interfere
        filePanelTableImp.flatTable.setRowSelectionInterval(1, 2);

        // go, go, go...

        // First a useless remove: this file doesn't exist in the hierarchy created by setup().
        filePanelTableImp.remove(new DefaultFileData(getTestFile("files/level11/11.txt"), uploadPolicy));
        assertEquals("after useless removal", 3, filePanelTableImp.getFilesLength());
        assertEquals("after useless removal", nbSubfoldersForSrcTestResourcesFiles + 8,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot().getTotalChildCount());

        // Then, the real ones
        filePanelTableImp.remove(rows.get(1));
        filePanelTableImp.remove(rows.get(2));
        filePanelTableImp.remove(rows.get(0));

        // Checks
        assertEquals("after 2", 0, filePanelTableImp.getFilesLength());
        assertEquals("after useless removal", nbSubfoldersForSrcTestResourcesFiles + 5,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot().getTotalChildCount());
    }

    /**
     * Test method for {@link wjhk.jupload2.gui.filepanel.FilePanelTableImp#removeAll()}.
     */
    @Test
    public void testRemoveAll() {
        // Preparation
        assertEquals("before 1", 3, filePanelTableImp.getFiles().size());
        assertEquals("before 2", 3, filePanelTableImp.getFilesLength());
        // check on absolute root
        assertEquals("before 3", nbSubfoldersForSrcTestResourcesFiles + 8,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot().getTotalChildCount());
        // check on visible root
        assertEquals("filePanelTableImp.addFiles (visible root)", 7,
                ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getRoot().getTotalChildCount());

        // go, go, go...
        filePanelTableImp.removeAll();

        // Checks
        assertEquals("after 1", 0, filePanelTableImp.getFiles().size());
        assertEquals("after 2", 0, filePanelTableImp.getFilesLength());
        // check on absolute root
        assertEquals("after 3", 0, ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getAbsoluteRoot()
                .getTotalChildCount());
        // check on visible root
        assertEquals("after 4", 0, ((FileDataTreeViewModel) this.filePanelTableImp.treeModel).getRoot()
                .getTotalChildCount());
    }

    /**
     * Test method for {@link wjhk.jupload2.gui.filepanel.FilePanelTableImp#clearSelection()}.
     */
    @Test
    public void testClearSelection_FlatView() {
        // Preparation
        filePanelTableImp.flatTable.setRowSelectionInterval(1, 2);
        assertEquals("before 2", 2, filePanelTableImp.flatTable.getSelectedRowCount());

        // go, go, go...
        filePanelTableImp.clearSelection();

        // Checks
        assertEquals("before 2", 0, filePanelTableImp.flatTable.getSelectedRowCount());
    }

    /**
     * Test method for {@link wjhk.jupload2.gui.filepanel.FilePanelTableImp#clearSelection()}.
     */
    @Test
    @Ignore("Selection is not yet implemented in tree view")
    public void testClearSelection_TreeView() {
        fail("not implemented");
    }

    /**
     * Test method for {@link wjhk.jupload2.gui.filepanel.FilePanelTableImp#getFileDataAt(java.awt.Point)}.
     */
    @Test
    public void testGetFileDataAt() {
        // Preparation
        Point p = new Point(5, 5);

        // go, go, go...
        FileData fd = filePanelTableImp.getFileDataAt(p);

        // Checks
        assertEquals("before 2", "ATestFile3.txt", fd.getFileName());
    }

}
