package wjhk.jupload2.gui.filepanel.treeview;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import wjhk.jupload2.JUploadDaemon;
import wjhk.jupload2.exception.JUploadException;
import wjhk.jupload2.exception.JUploadExceptionStopAddingFiles;
import wjhk.jupload2.exception.JUploadIOException;
import wjhk.jupload2.filedata.DefaultFileData;
import wjhk.jupload2.testhelpers.FilePanelTestHelper;
import wjhk.jupload2.testhelpers.JUploadPanelTestHelper;
import wjhk.jupload2.testhelpers.UploadPolicyTestHelper;
import wjhk.jupload2.upload.AbstractJUploadTestHelper;
import wjhk.jupload2.upload.helper.ByteArrayEncoderHTTP;

public class FolderNodeTest extends AbstractJUploadTestHelper {

    File folderContainingTestResources = null;

    File root = new File(".");

    FolderNode folderNode = null;

    @Before
    public void setUp() throws Exception {
        // Set the postURL for the current unit test, according to the local network access.
        setPostURL();

        this.juploadDaemon = new JUploadDaemon();
        this.filePanel = new FilePanelTestHelper(this.filesToUpload);
        this.juploadPanel = new JUploadPanelTestHelper(this.filePanel);
        this.uploadPolicy = new UploadPolicyTestHelper(this.juploadPanel);

        folderContainingTestResources = AbstractJUploadTestHelper.getTestFile(File.separator + "files");
        assertTrue("file is dir", folderContainingTestResources.isDirectory());
        folderNode = (FolderNode) this.fileDataTreeViewModel.getTreePathFromFile(folderContainingTestResources, true)
                .getLastPathComponent();
        this.fileDataTreeViewModel.setRoot(folderNode);
        assertEquals("Check model", this.fileDataTreeViewModel, folderNode.treeModel);
    }

    /**
     * Adds some tests nodes, to have a real case hierarchy, loaded in the tree view.
     */
    private void addTestNodesToTree() {
        FolderNode subfolder = new FolderNode(new File(folderContainingTestResources, "level1"), uploadPolicy,
                this.fileDataTreeViewModel, this.filePanelFlatDataModel2);
        folderNode.addChild(subfolder);
        subfolder.addChild(new FileDataNode(new DefaultFileData(new File(folderContainingTestResources,
                "level1/ATestFile.txt"), uploadPolicy)));

        folderNode.addChild(new FileDataNode(new DefaultFileData(new File(folderContainingTestResources, "1.txt"),
                uploadPolicy)));
        folderNode.addChild(new FileDataNode(new DefaultFileData(new File(folderContainingTestResources, "2.txt"),
                uploadPolicy)));
        folderNode.addChild(new FileDataNode(new DefaultFileData(new File(folderContainingTestResources, "3.txt"),
                uploadPolicy)));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFolderNode_OK() {
        addTestNodesToTree();

        assertNotNull("not null", folderNode);
        assertEquals("getChildren", 4, folderNode.getChildren().size());
        assertEquals("getFileName", "files", folderNode.getFileName());
        assertEquals("getFileLength", -1, folderNode.getFileLength());
        assertEquals("getLastModified", new Date(this.folderContainingTestResources.lastModified()),
                folderNode.getLastModified());
        assertEquals("getDirectory", folderContainingTestResources.getAbsoluteFile().getParent(),
                folderNode.getDirectory());
        assertEquals("canRead", true, folderNode.canRead());
        assertEquals("getAbsolutePath", folderContainingTestResources.getAbsolutePath(), folderNode.getAbsolutePath());
        assertEquals("getChildCount", 4, folderNode.getChildCount());
        assertEquals("getChild", "2.txt", folderNode.getChild(2).getFileName());
        assertEquals("getChild", "2.txt", folderNode.getChild("2.txt").getFileName());
        assertEquals("isLeaf", false, folderNode.isLeaf());
        assertEquals("parent", "test-classes", folderNode.getParent().toString());
        assertEquals("model", this.fileDataTreeViewModel, folderNode.treeModel);

        // All children have this as a parent, and the same model.
        for (TreeFileDataNode tfdn : (List<TreeFileDataNode>) (List<?>) folderNode.getChildren()) {
            assertEquals("parent for " + tfdn, folderNode, tfdn.getParent());
            if (tfdn instanceof FileDataNode) {
                assertEquals("parent for " + tfdn, folderNode.treeModel, ((FileDataNode) tfdn).treeModel);
            } else {
                assertEquals("parent for " + tfdn, folderNode.treeModel, ((FolderNode) tfdn).treeModel);
            }
        }

    }

    @Test(expected = IllegalArgumentException.class)
    public void testFolderNodeFile_KO() {
        addTestNodesToTree();

        folderNode = new FolderNode(new File(folderContainingTestResources, "1.txt"), uploadPolicy,
                this.fileDataTreeViewModel, this.filePanelFlatDataModel2);
    }

    @Test(expected = IllegalAccessError.class)
    public void testAppendFileProperties() throws JUploadIOException {
        addTestNodesToTree();

        folderNode.appendFileProperties(new ByteArrayEncoderHTTP(uploadPolicy), 1);
    }

    @Test(expected = IllegalAccessError.class)
    public void testAppendFileExtension() throws JUploadIOException {
        addTestNodesToTree();

        assertEquals("getFileExtension", "txt", folderNode.getFileExtension());
    }

    @Test(expected = IllegalAccessError.class)
    public void testBeforeUpload() throws JUploadException {
        addTestNodesToTree();

        folderNode.beforeUpload(null);
    }

    @Test(expected = IllegalAccessError.class)
    public void testGetUploadLength() {
        addTestNodesToTree();

        folderNode.getUploadLength();
    }

    @Test(expected = IllegalAccessError.class)
    public void testAfterUpload() {
        addTestNodesToTree();

        folderNode.afterUpload();
    }

    @Test(expected = IllegalAccessError.class)
    public void testGetInputStream() throws JUploadException {
        addTestNodesToTree();

        folderNode.getInputStream();
    }

    @Test
    public void testGetUploadFlag() {
        // Preparation
        addTestNodesToTree();
        checkUploadFlag("testGetUploadFlag (before)", true, folderNode);

        // First shot
        folderNode.setUploadFlag(false);
        checkUploadFlag("testGetUploadFlag (false)", false, folderNode);

        // Second shot
        folderNode.setUploadFlag(true);
        checkUploadFlag("testGetUploadFlag (true)", true, folderNode);
    }

    /**
     * 
     */
    private void checkUploadFlag(String msg, boolean expected, FolderNode node) {
        assertEquals(msg + " (node) for " + node, expected, node.getUploadFlag());
        for (TreeFileDataNode tfdn : node.children) {
            if (tfdn instanceof FolderNode) {
                checkUploadFlag(msg + " (" + tfdn + ") ", expected, (FolderNode) tfdn);
            } else {
                assertEquals(msg + " (children) for " + tfdn, expected, tfdn.getUploadFlag());
            }
        }// for
    }

    @Test(expected = IllegalAccessError.class)
    public void testGetMD5() throws JUploadException {
        addTestNodesToTree();

        folderNode.getMD5();
    }

    @Test(expected = IllegalAccessError.class)
    public void testGetMimeType() {
        addTestNodesToTree();

        folderNode.getMimeType();
    }

    @Test(expected = IllegalAccessError.class)
    public void testIsPreparedForUpload() {
        addTestNodesToTree();

        folderNode.isPreparedForUpload();
    }

    @Test
    public void testGetChildOrCreateIt() {
        addTestNodesToTree();
        assertEquals("getChildCount", 4, folderNode.getChildCount());

        // Adding a new FileDataNode
        FileDataNode fdn4 = (FileDataNode) folderNode.addChild(new FileDataNode(new DefaultFileData(new File(
                folderContainingTestResources, "4.txt"), uploadPolicy)));
        assertEquals("getChildCount (fdn4)", 5, folderNode.getChildCount());
        assertEquals("getFileName (fdn4)", "4.txt", fdn4.getFileName());
        assertEquals("parent (fdn4)", folderNode, fdn4.getParent());
        assertEquals("model (fdn4)", this.fileDataTreeViewModel, fdn4.treeModel);

        // Getting an existing FileDatanode.
        FileDataNode fdn3 = (FileDataNode) folderNode.addChild(new FileDataNode(new DefaultFileData(new File(
                folderContainingTestResources, "3.txt"), uploadPolicy)));
        assertEquals("getChildCount (fdn3)", 5, folderNode.getChildCount());
        assertEquals("getFileName (fdn3)", "3.txt", fdn3.getFileName());
        assertEquals("parent (fdn3)", folderNode, (FolderNode) fdn3.getParent());
        assertEquals("model (fdn3)", this.fileDataTreeViewModel, fdn3.treeModel);
    }

    @Test
    public void testGetSubfolderOrCreateIt() throws JUploadExceptionStopAddingFiles {
        addTestNodesToTree();
        // Adding a new FolderNode
        FolderNode fn4 = (FolderNode) folderNode.getSubfolderOrCreateIt(new File(folderContainingTestResources,
                "level11"));
        assertEquals("getChildCount (folderNode fn4)", 5, folderNode.getChildCount());
        assertEquals("getChildCount (fn4)", 0, fn4.getChildCount());
        assertEquals("getFileName (fn4)", "level11", fn4.getFileName());
        assertEquals("parent (fdn4)", folderNode, fn4.getParent());
        assertEquals("model (fdn4)", this.fileDataTreeViewModel, fn4.treeModel);

        // Adding an existing FolderNode
        FolderNode fn5 = (FolderNode) folderNode.getSubfolderOrCreateIt(new File(folderContainingTestResources,
                "level1"));
        assertEquals("getChildCount (folderNode fn5)", 5, folderNode.getChildCount());
        assertEquals("getChildCount (fn5)", 1, fn5.getChildCount());
        assertEquals("getFileName (fn5)", "level1", fn5.getFileName());
        assertTrue("parent (fn5)", folderNode == fn5.getParent());
        assertTrue("model (fn5)", this.fileDataTreeViewModel == fn5.treeModel);
    }

    @Test
    public void testRemove() {
        addTestNodesToTree();
        // Checks before
        assertEquals("before children", 4, folderNode.getChildCount());

        // Let's remove one child (FileDataNode)
        FileDataNode fdn1 = (FileDataNode) folderNode.children.get(1);
        assertEquals("before removing fdn1 (children count)" + fdn1, 4, folderNode.getChildCount());
        assertEquals("before removing fdn1 (fdn children count)" + fdn1, 0, fdn1.getChildCount());
        assertEquals("before removing fdn1 (fdn parent)" + fdn1, folderNode, fdn1.parent);
        assertEquals("before removing fdn1 (fdn model)" + fdn1, folderNode.treeModel, fdn1.treeModel);
        this.folderNode.removeChild(fdn1);
        assertEquals("before removing fdn1 (children count)" + fdn1, 3, folderNode.getChildCount());
        assertEquals("before removing fdn1 (fdn children count)" + fdn1, 0, fdn1.getChildCount());
        assertEquals("before removing fdn1 (fdn parent)" + fdn1, null, fdn1.parent);
        assertEquals("before removing fdn1 (fdn model)" + fdn1, null, fdn1.treeModel);

        // Let's try to remove an item which is not a child
        FileDataNode fdn2 = new FileDataNode(new DefaultFileData(new File("files/5.txt"), uploadPolicy));
        try {
            this.folderNode.removeChild(fdn2);
            fail("A IllegalArgumentException should have been raised");
        } catch (IllegalArgumentException e) {
            // OK !
        }

        // Let's try to remove a subfolder
        // Let's find a subfolder of fdn3. It should also be cleared by the removal of fdn3 (to avoid memory leak)
        FolderNode fdn3 = null;
        for (MyTreeNode mtn : folderNode.getChildren()) {
            if (mtn instanceof FolderNode) {
                fdn3 = (FolderNode) mtn;
                break;
            }
        }
        assertNotNull("There must be at least on subFolder" + fdn3, fdn3);
        assertTrue("The subFolder should have at least one child " + fdn3, fdn3.getChildCount() > 0);
        this.folderNode.removeChild(fdn3);
        assertEquals("after removing fdn3 (children count)" + fdn3, 2, folderNode.getChildCount());
        assertEquals("after removing fdn3 (fdn children count)" + fdn3, 0, fdn3.getChildCount());
        assertEquals("after removing fdn3 (fdn parent)" + fdn3, null, fdn3.parent);
        assertEquals("after removing fdn3 (fdn model)" + fdn3, null, fdn3.treeModel);
        assertNotNull("after removing - There must be at least on subFolder", fdn3);
        assertEquals("after removing - The subFolder should have at least on child", 0, fdn3.getChildCount());
        assertEquals("after removing fdn3 (subFolder1 parent)" + fdn3, null, fdn3.parent);
        assertEquals("after removing fdn3 (subFolder1 model)" + fdn3, null, fdn3.treeModel);

        // Let's remove the two last children
        this.folderNode.removeChild(folderNode.children.get(0));
        this.folderNode.removeChild(folderNode.children.get(0));
        assertEquals("after removing last child (children count)", 0, folderNode.getChildCount());
        assertEquals("after removing last child (fdn parent)", null, fdn3.parent);
        assertEquals("after removing last child (fdn model)", null, fdn3.treeModel);
    }

    /**
     * @throws JUploadExceptionStopAddingFiles
     */
    @Test
    public void testAddChildFile() throws JUploadExceptionStopAddingFiles {
        // Preparation
        assertEquals("nb children Before", 0, folderNode.getChildCount());
        File subfolderLevel11 = new File(folderContainingTestResources, "level11");
        File fsubsubfolderLevel111 = new File(subfolderLevel11, "level111");

        // Go, go, go
        TreeFileDataNode folderNodeLevel2 = folderNode.addChild(fsubsubfolderLevel111);

        // Verification
        assertEquals("nb children After (1)", 1, folderNode.getChildCount());
        assertEquals("no children for new node (1)", 0, folderNodeLevel2.getChildCount());
        assertTrue("new node is FolderNode", folderNodeLevel2 instanceof FolderNode);

        // Preparation
        File fsubsubfolderFile11 = new File(subfolderLevel11, "11.txt");

        // Go, go, go
        TreeFileDataNode fileNodeFile11 = folderNode.addChild(fsubsubfolderFile11);

        // Verification
        assertEquals("nb children After (2)", 2, folderNode.getChildCount());
        assertEquals("no children for new node (2)", 0, fileNodeFile11.getChildCount());
        assertTrue("new node is FileDataNode", fileNodeFile11 instanceof FileDataNode);
    }
}
