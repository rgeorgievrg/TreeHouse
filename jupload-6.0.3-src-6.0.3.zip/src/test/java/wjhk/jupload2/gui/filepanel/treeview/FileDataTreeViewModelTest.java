package wjhk.jupload2.gui.filepanel.treeview;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.swing.tree.TreePath;

import org.junit.Before;
import org.junit.Test;

import wjhk.jupload2.exception.JUploadExceptionStopAddingFiles;
import wjhk.jupload2.filedata.DefaultFileData;
import wjhk.jupload2.gui.filepanel.FilePanel;
import wjhk.jupload2.policies.UploadPolicy;
import wjhk.jupload2.upload.AbstractJUploadTestHelper;

public class FileDataTreeViewModelTest extends AbstractJUploadTestHelper {

    @Before
    public void setUp() throws Exception {
        fileDataTreeViewModel = new FileDataTreeViewModel(uploadPolicy, this.filePanelFlatDataModel2);
    }

    @Test
    public void testFileDataTreeViewModel() {
        assertEquals("uploadPolicy", uploadPolicy, fileDataTreeViewModel.uploadPolicy);
    }

    @Test
    public void testGetColumnCount() {
        assertEquals(5, fileDataTreeViewModel.getColumnCount());
    }

    @Test
    public void testGetColumnName() {
        // The mock UploadPolicy doesn't translate strings. We just get the property for the localized strings
        assertEquals("Name", "colName", fileDataTreeViewModel.getColumnName(0));
        assertEquals("Size", "colSize", fileDataTreeViewModel.getColumnName(1));
        assertEquals("Directory", "colDirectory", fileDataTreeViewModel.getColumnName(2));
        assertEquals("Modified", "colModified", fileDataTreeViewModel.getColumnName(3));
        assertEquals("Checked", "", fileDataTreeViewModel.getColumnName(4));
    }

    @Test
    public void testGetColumnSizePercentage() {
        assertEquals(
                "100%",
                100,
                fileDataTreeViewModel.getColumnSizePercentage(0) + fileDataTreeViewModel.getColumnSizePercentage(1)
                        + fileDataTreeViewModel.getColumnSizePercentage(2)
                        + fileDataTreeViewModel.getColumnSizePercentage(3)
                        + fileDataTreeViewModel.getColumnSizePercentage(4));
    }

    @Test
    public void testGetColumnClass() {
        assertEquals("Name", MyTreeTableModel.class, fileDataTreeViewModel.getColumnClass(0));
        assertEquals("Size", Long.class, fileDataTreeViewModel.getColumnClass(1));
        assertEquals("Directory", String.class, fileDataTreeViewModel.getColumnClass(2));
        assertEquals("Modified", Date.class, fileDataTreeViewModel.getColumnClass(3));
        assertEquals("Checked", Boolean.class, fileDataTreeViewModel.getColumnClass(4));
    }

    @Test
    public void testGetValueAtTreeFileDataNodeInt() {
        // Test with real Node
        FileDataNode fd = new FileDataNode(new DefaultFileData(getTestFile("3.txt"), uploadPolicy));
        fd.setUploadFlag(false);
        checkNodeValue(fd, fd, "");

        // Test with null Node
        assertNull("node null", fileDataTreeViewModel.getValueAt(null, 1));
    }

    /**
     * @param fd
     */
    private void checkNodeValue(FileDataNode fdExpected, FileDataNode fdToBeChecked, String testMsg) {
        assertEquals("filename (" + testMsg + ")", fdExpected.getFileName(),
                fileDataTreeViewModel.getValueAt(fdToBeChecked, 0));
        assertEquals("size (" + testMsg + ")", fdExpected.getFileLength(),
                fileDataTreeViewModel.getValueAt(fdToBeChecked, 1));
        assertEquals("directory (" + testMsg + ")", fdExpected.getDirectory(),
                fileDataTreeViewModel.getValueAt(fdToBeChecked, 2));
        assertEquals("modified (" + testMsg + ")", fdExpected.getLastModified(),
                fileDataTreeViewModel.getValueAt(fdToBeChecked, 3));
        assertEquals("checked (" + testMsg + ")", fdExpected.getUploadFlag(),
                (Boolean) fileDataTreeViewModel.getValueAt(fdToBeChecked, 4));
    }

    @Test
    public void testIsCellEditable() {
        assertTrue("Name", fileDataTreeViewModel.isCellEditable(null, 0));
        assertFalse("Size", fileDataTreeViewModel.isCellEditable(null, 1));
        assertFalse("Directory", fileDataTreeViewModel.isCellEditable(null, 2));
        assertFalse("Modified", fileDataTreeViewModel.isCellEditable(null, 3));
        assertTrue("Checked", fileDataTreeViewModel.isCellEditable(null, 4));
    }

    @Test
    public void testSetValueAt() {
        // Test with real Node
        FileDataNode fdCheck = new FileDataNode(new DefaultFileData(getTestFile("1.txt"), uploadPolicy));
        FileDataNode fdToUpdate = new FileDataNode(new DefaultFileData(getTestFile("1.txt"), uploadPolicy));
        fdCheck.setUploadFlag(false);
        fdToUpdate.setUploadFlag(false);

        // Should not generate a change
        fileDataTreeViewModel.setValueAt("new name", fdToUpdate, 0);
        checkNodeValue(fdCheck, fdToUpdate, "0");

        // Should not generate a change
        fileDataTreeViewModel.setValueAt(10000, fdToUpdate, 1);
        checkNodeValue(fdCheck, fdToUpdate, "1");

        // Should not generate a change
        fileDataTreeViewModel.setValueAt("new directory", fdToUpdate, 2);
        checkNodeValue(fdCheck, fdToUpdate, "2");

        // Should not generate a change
        fileDataTreeViewModel.setValueAt(12314, fdToUpdate, 3);
        checkNodeValue(fdCheck, fdToUpdate, "3");

        // Should GENERATE a change
        assertFalse("Checked", fdToUpdate.getUploadFlag());
        fdCheck.setUploadFlag(true);
        fileDataTreeViewModel.setValueAt(true, fdToUpdate, 4);
        checkNodeValue(fdCheck, fdToUpdate, "4");
        assertTrue("Checked", fdToUpdate.getUploadFlag());
    }

    @Test(expected = NullPointerException.class)
    public void testSetValueAt_NullNode() {
        fileDataTreeViewModel.setValueAt(true, null, 4);
    }

    @Test
    public void testGetTreePathFromFile_createDescendant_false() throws IOException, JUploadExceptionStopAddingFiles {
        // Check for the FS root
        TreePath rootTreePath = fileDataTreeViewModel.getTreePathFromFile(getRootPath(), false);
        assertNull("No path for current FS root, as called with false", rootTreePath);

        // Check for the current folder
        String currentPath = new File(".").getCanonicalPath();
        TreePath folderTreePath = fileDataTreeViewModel.getTreePathFromFile(new File(currentPath), false);
        assertNull("No path for folder, as called with false", folderTreePath);

        // Check for a file.
        File f2 = getTestFile("files/level1/level2");
        TreePath fileTreePath = fileDataTreeViewModel.getTreePathFromFile(f2, false);
        assertNull("No path for file, as called with false", fileTreePath);
    }

    @Test(expected = IllegalStateException.class)
    public void testGetTreePathFromFile_independantTreeView() throws JUploadExceptionStopAddingFiles {

        // Preparation
        String oldValue = System.getProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE);
        System.setProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE,
                FilePanel.FileListViewMode.INDEPENDENT_TREE_VIEW.toString());

        // go, go, go
        try {
            fileDataTreeViewModel.getTreePathFromFile(new File("."), true);
        } finally {
            // Cleaning
            if (oldValue == null) {
                System.clearProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE);
            } else {
                System.setProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE, oldValue);
            }
        }
    }

    @Test
    public void testGetTreePathFromFile_createDescendant_true() throws JUploadExceptionStopAddingFiles {
        // Check for the FS root
        assertEquals("Empty tree", 0, getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
        TreePath rootTreePath = fileDataTreeViewModel.getTreePathFromFile(getRootPath(), true);
        assertEquals("rootTreePath - nb items", 2, rootTreePath.getPathCount());
        assertEquals("rootTreePath - root", "", ((FolderNode) rootTreePath.getPathComponent(0)).getFileName());

        // go, go, go (null file)
        TreePath treePathNull = fileDataTreeViewModel.getTreePathFromFile(null, true);

        // Verification
        assertEquals("With a null file, it should return the root", fileDataTreeViewModel.getAbsoluteRoot(),
                treePathNull.getLastPathComponent());
        assertEquals("null file, last component", fileDataTreeViewModel.absoluteRoot,
                treePathNull.getLastPathComponent());
        assertEquals("null file, nb path", 1, treePathNull.getPath().length);

        // go, go, go (Real file)
        TreePath treePath = fileDataTreeViewModel.getTreePathFromFile(new File(getTestFilesRootPath()), true);
        FolderNode folderNode = (FolderNode) treePath.getLastPathComponent();

        // Verification
        assertEquals("Real file", nbSubfoldersForSrcTestResourcesFiles,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
        assertEquals("folderNode", "files", folderNode.getFileName());
    }

    /** Get the root of the current FS. e.g.: /, C:, \\myserver.com\ ... */
    private File getRootPath() {
        String fCurrentPath = new File(".").getAbsolutePath();
        // fCurrentPath can start by "/" (unix, mac) or by a drive letter (windows, e.g.: C:, D:...) or by network path
        File fsRoot = null;
        if (fCurrentPath.startsWith("/")) {
            // Unix or Mac FS
            fsRoot = new File("/");
        } else if (fCurrentPath.substring(1, 2).equals(":")) {
            // Windows FS
            fsRoot = new File(fCurrentPath.substring(0, 2) + "\\");
        } else if (fCurrentPath.substring(0, 2).equals("\\\\")) {
            // It's a netbios FS. It starts by \\servername\). Let's find the end of the servername :
            int iEndServerName = fCurrentPath.indexOf('\\', 2);
            fsRoot = new File(fCurrentPath.substring(0, iEndServerName + 1));
        } else {
            fail("Unknown File Absolute Path: " + fCurrentPath);
        }
        return fsRoot;
    }

    /*
     * @Test public void testGetFolderNodeForNewFileFile() throws JUploadExceptionStopAddingFiles { // Preparation
     * assertEquals("Empty tree", 0, fileDataTreeViewModel.getAbsoluteRoot().getChildCount()); // Null file
     * assertEquals("With a null file, it should return the root", fileDataTreeViewModel.getAbsoluteRoot(),
     * fileDataTreeViewModel.getFolderNodeForNewFile(null)); // Real file FolderNode folderNode =
     * fileDataTreeViewModel.getFolderNodeForNewFile(new File(getTestFilesRootPath())); assertEquals("Real file",
     * nbSubfoldersForSrcTestResourcesFiles, fileDataTreeViewModel.getAbsoluteRoot() .getChildCount());
     * assertEquals("folderNode", "files", folderNode.getFileName()); }
     */
    /**
     * Actually the same test as testGetFolderNodeForNewFileFile, but with an additional null as a parameter to
     * getFolderNodeForNewFile
     * 
     * @throws JUploadExceptionStopAddingFiles
     */
    /*
     * @Test public void testGetFolderNodeForNewFileFileFolderNode_parentNode_null() throws
     * JUploadExceptionStopAddingFiles { // Preparation assertEquals("Empty tree", 0,
     * fileDataTreeViewModel.getAbsoluteRoot().getChildCount()); // Null file
     * assertEquals("With a null file, it should return the root", fileDataTreeViewModel.getAbsoluteRoot(),
     * fileDataTreeViewModel.getFolderNodeForNewFile(null, null)); // Real file FolderNode folderNode =
     * fileDataTreeViewModel.getFolderNodeForNewFile(new File(getTestFilesRootPath()), null); assertEquals("Real file",
     * nbSubfoldersForSrcTestResourcesFiles, fileDataTreeViewModel.getAbsoluteRoot() .getChildCount());
     * assertEquals("folderNode", "files", folderNode.getFileName()); }
     * @Test public void testGetFolderNodeForNewFileFileFolderNode() throws JUploadExceptionStopAddingFiles { //
     * Preparation // Let's create a first folder, with all its hierarchy. It's tested here above. FolderNode
     * parentFolderNode = fileDataTreeViewModel.getFolderNodeForNewFile(new File(getTestFilesRootPath()), null); File
     * subfolderLevel1 = new File(getTestFilesRootPath(), "level1"); File subsubfolderLevel2 = new File(subfolderLevel1,
     * "level2"); // go, go, go FolderNode folderNode =
     * fileDataTreeViewModel.getFolderNodeForNewFile(subsubfolderLevel2, parentFolderNode); // Verification
     * assertEquals("Real file", nbSubfoldersForSrcTestResourcesFiles + 2, fileDataTreeViewModel.getAbsoluteRoot()
     * .getChildCount()); assertEquals("folderNode", "level2", folderNode.getFileName()); }
     */

    @Test(expected = IllegalArgumentException.class)
    public void testAttachObject_BadType() throws IllegalArgumentException, JUploadExceptionStopAddingFiles {
        fileDataTreeViewModel.attachObject(this);
    }

    @Test
    public void testAttachObject() throws IllegalArgumentException, JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        assertEquals("Tree is empty", 0, fileDataTreeViewModel.getAbsoluteRoot().getChildCount());

        // Go, go, go
        int nbAttachedObjects = fileDataTreeViewModel.attachObject(file);

        // Verification
        assertEquals("nbAttachedObjects", 18, nbAttachedObjects);
        assertEquals("Real file", 1, fileDataTreeViewModel.getAbsoluteRoot().getChildCount());
        assertEquals("Real file", nbSubfoldersForSrcTestResourcesFiles + 25,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
    }

    private int getNbDescendants(TreeFileDataNode node) {
        int nbDescendant = 0;
        for (MyTreeNode child : node.getChildren()) {
            nbDescendant += 1; // The child
            nbDescendant += getNbDescendants((TreeFileDataNode) child); // The children's child
        }// for
        return nbDescendant;
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetTreePathForObject_badType() {
        fileDataTreeViewModel.getTreePathForObject(this, false);
    }

    @Test
    public void testGetTreePathForObject_notCreated_false() throws IllegalArgumentException,
            JUploadExceptionStopAddingFiles {
        // No preparation
        File file = new File(getTestFilesRootPath());

        // go, go, go
        TreePath treePath = fileDataTreeViewModel.getTreePathForObject(file, false);

        // Verification
        assertNull(treePath);
    }

    @Test
    public void testGetTreePathForObject_notCreated_true() throws IllegalArgumentException,
            JUploadExceptionStopAddingFiles {
        // No preparation
        File file = new File(getTestFilesRootPath());

        // go, go, go
        TreePath treePath = fileDataTreeViewModel.getTreePathForObject(file, true);

        // Verification
        assertEquals("The node must be created during the process", "files", treePath.getLastPathComponent().toString());
    }

    @Test
    public void testGetTreePathForObject() throws IllegalArgumentException, JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);

        // go, go, go
        TreePath treePath = fileDataTreeViewModel.getTreePathForObject(file, false);

        // Verification
        assertTrue("folderNode", treePath.getLastPathComponent() instanceof FolderNode);
        assertEquals("filename", "files", ((FolderNode) treePath.getLastPathComponent()).getFileName());
    }

    @Test
    public void testMyAbstractTreeTableModel() {
        assertEquals("uploadPolicy", uploadPolicy, fileDataTreeViewModel.uploadPolicy);

        assertNotNull("absoluteRoot", fileDataTreeViewModel.absoluteRoot);
        assertTrue("absoluteRoot RootNode", fileDataTreeViewModel.absoluteRoot instanceof RootNode);
        assertEquals("absoluteRoot TreeModel", fileDataTreeViewModel,
                ((RootNode) fileDataTreeViewModel.absoluteRoot).treeModel);
        assertNotNull("absoluteRoot FlatModel", ((RootNode) fileDataTreeViewModel.absoluteRoot).flatModel);

        assertNotNull("visibleRoot", fileDataTreeViewModel.visibleRoot);
        assertTrue("visibleRoot RootNode", fileDataTreeViewModel.visibleRoot instanceof RootNode);
        assertNotNull("absoluteRoot flatModel", ((RootNode) fileDataTreeViewModel.visibleRoot).flatModel);
    }

    @Test
    public void testGetSetTree() {
        // Start
        assertEquals(fileDataTreeViewModel.tree, fileDataTreeViewModel.getTree());

        // Update
        fileDataTreeViewModel.setTree(null);
        assertNull("null", fileDataTreeViewModel.getTree());
    }

    @Test
    public void testGetAbsoluteRoot() {
        assertEquals(fileDataTreeViewModel.absoluteRoot, fileDataTreeViewModel.getAbsoluteRoot());
    }

    @Test
    public void testGetSetRoot() {
        // Start (absoluteRoot = visibleRoot
        assertEquals("absoluteRoot", fileDataTreeViewModel.absoluteRoot, fileDataTreeViewModel.getRoot());
        assertNotNull("not null", fileDataTreeViewModel.getRoot());

        // Update
        RootNode newRoot = new RootNode(uploadPolicy, fileDataTreeViewModel, filePanelFlatDataModel2);
        fileDataTreeViewModel.setRoot(newRoot);
        assertEquals("newRoot", newRoot, fileDataTreeViewModel.getRoot());
    }

    @Test
    public void testRemove() throws IllegalArgumentException, JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);
        assertEquals("Start", nbSubfoldersForSrcTestResourcesFiles + 25,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
        TreeFileDataNode tfdnATextFile3 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level2/level3/ATestFile3.txt"), false).getLastPathComponent();
        TreeFileDataNode tfdnATextFile33 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level2/level33/ATestFile33.txt"), false).getLastPathComponent();
        TreeFileDataNode tfdnATextFolder1 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1"), false).getLastPathComponent();

        // go, go, go (and check)
        fileDataTreeViewModel.remove(tfdnATextFile3);
        assertEquals("tfdnATextFile3", nbSubfoldersForSrcTestResourcesFiles + 24,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));

        // go, go, go (and check)
        fileDataTreeViewModel.remove(tfdnATextFile33);
        assertEquals("tfdnATextFile33", nbSubfoldersForSrcTestResourcesFiles + 23,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));

        // go, go, go (and check)
        fileDataTreeViewModel.remove(tfdnATextFolder1);
        assertEquals("tfdnATextFolder1", nbSubfoldersForSrcTestResourcesFiles + 16,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
    }

    @Test
    public void testGetTreePath() throws JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        TreePath treePathCheck = fileDataTreeViewModel.getTreePathFromFile(file, true);

        // go, go, go
        TreePath treePathExec = fileDataTreeViewModel.getTreePath((TreeFileDataNode) treePathCheck
                .getLastPathComponent());

        // Verification
        assertEquals("Nb levels", treePathCheck.getPathCount(), treePathExec.getPathCount());
        for (int i = 0; i < treePathExec.getPathCount(); i += 1) {
            assertEquals("filename " + i, treePathCheck.getPath()[i].toString(), treePathExec.getPath()[i].toString());
        }// for
    }

    @Test
    public void testCleanHierarchy() throws JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);
        assertEquals("Real file", nbSubfoldersForSrcTestResourcesFiles + 25,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
        TreeFileDataNode tfdnATextFile3 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level2/level3/ATestFile3.txt"), false).getLastPathComponent();
        TreeFileDataNode tfdnATextFile33 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level2/level33/ATestFile33.txt"), false).getLastPathComponent();
        TreeFileDataNode tfdnATextFile22 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level22/ATestFile22.txt"), false).getLastPathComponent();
        fileDataTreeViewModel.remove(tfdnATextFile3);
        fileDataTreeViewModel.remove(tfdnATextFile33);
        fileDataTreeViewModel.remove(tfdnATextFile22);

        // go, go, go
        fileDataTreeViewModel.cleanHierarchy();

        // Verification
        assertEquals("Tree has been cleaned", nbSubfoldersForSrcTestResourcesFiles + 18,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
    }

    @Test
    public void testCleanHierarchyT() throws JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);
        assertEquals("Real file", nbSubfoldersForSrcTestResourcesFiles + 25,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
        TreeFileDataNode tfdnATextFile3 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level2/level3/ATestFile3.txt"), false).getLastPathComponent();
        TreeFileDataNode tfdnATextFile33 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level2/level33/ATestFile33.txt"), false).getLastPathComponent();
        TreeFileDataNode tfdnATextFile22 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level22/ATestFile22.txt"), false).getLastPathComponent();
        fileDataTreeViewModel.remove(tfdnATextFile3); // Behind level2
        fileDataTreeViewModel.remove(tfdnATextFile33); // Behind level2
        fileDataTreeViewModel.remove(tfdnATextFile22);// No behind level2 (level22 is a "no children" folder, but should
                                                      // not be cleared
        TreeFileDataNode tfdnFolder2 = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(
                getTestFile("files/level1/level2"), false).getLastPathComponent();

        // go, go, go
        boolean ret = fileDataTreeViewModel.cleanHierarchy(tfdnFolder2);

        // Verification
        assertTrue("Return", ret);
        assertEquals("Tree has been cleaned", nbSubfoldersForSrcTestResourcesFiles + 20,
                getNbDescendants(fileDataTreeViewModel.getAbsoluteRoot()));
    }

    @Test
    public void testGetChild() throws JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);
        TreeFileDataNode tfdn = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(file, false)
                .getLastPathComponent();

        // go, go, go
        TreeFileDataNode tfdnChild = fileDataTreeViewModel.getChild(tfdn, 3);

        // Verification
        assertEquals("child index 3", "3.txt", tfdnChild.toString());
    }

    @Test
    public void testGetChildCount() throws JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);
        TreeFileDataNode tfdn = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(file, false)
                .getLastPathComponent();

        // go, go, go
        int childCount = fileDataTreeViewModel.getChildCount(tfdn);

        // Verification
        assertEquals("child index 3", 14, childCount);
    }

    @Test
    public void testIsLeaf() throws JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);
        TreeFileDataNode tfdn = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(file, false)
                .getLastPathComponent();
        TreeFileDataNode tfdnChild = fileDataTreeViewModel.getChild(tfdn, 3);

        // Verification
        assertFalse("folder", fileDataTreeViewModel.isLeaf(tfdn));
        assertTrue("file", fileDataTreeViewModel.isLeaf(tfdnChild));
    }

    @Test
    public void testGetIndexOfChild() throws JUploadExceptionStopAddingFiles {
        // Preparation
        File file = new File(getTestFilesRootPath());
        fileDataTreeViewModel.attachObject(file);
        TreeFileDataNode tfdn = (TreeFileDataNode) fileDataTreeViewModel.getTreePathFromFile(file, false)
                .getLastPathComponent();
        TreeFileDataNode tfdnChild = fileDataTreeViewModel.getChild(tfdn, 3);

        // Verification
        assertEquals(3, fileDataTreeViewModel.getIndexOfChild(tfdn, tfdnChild));
    }

}
