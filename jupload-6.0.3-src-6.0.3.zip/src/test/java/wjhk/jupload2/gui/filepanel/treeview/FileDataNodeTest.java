package wjhk.jupload2.gui.filepanel.treeview;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

import wjhk.jupload2.JUploadDaemon;
import wjhk.jupload2.exception.JUploadException;
import wjhk.jupload2.filedata.DefaultFileData;
import wjhk.jupload2.filedata.FileData;
import wjhk.jupload2.testhelpers.FilePanelTestHelper;
import wjhk.jupload2.testhelpers.JUploadPanelTestHelper;
import wjhk.jupload2.testhelpers.UploadPolicyTestHelper;
import wjhk.jupload2.upload.AbstractJUploadTestHelper;

public class FileDataNodeTest extends AbstractJUploadTestHelper {

    File file = null;

    File root = new File(".");

    FileData fileData = null;

    FileDataNode fileDataNode = null;

    @Before
    public void setUp() throws Exception {
        // Set the postURL for the current unit test, according to the local network access.
        setPostURL();

        this.juploadDaemon = new JUploadDaemon();
        this.filePanel = new FilePanelTestHelper(this.filesToUpload);
        this.juploadPanel = new JUploadPanelTestHelper(this.filePanel);
        this.uploadPolicy = new UploadPolicyTestHelper(this.juploadPanel);

        file = AbstractJUploadTestHelper.getTestFile(File.separator + "files" + File.separator + "1.txt");
        fileData = new DefaultFileData(file, uploadPolicy);
        fileDataNode = new FileDataNode(fileData);
    }

    @Test
    public void testFileDataNode() {
        assertNotNull("not null", fileDataNode);
        assertEquals("getChildren", 0, fileDataNode.getChildren().size());
        assertEquals("getFileName", "1.txt", fileDataNode.getFileName());
        assertEquals("getFileExtension", "txt", fileDataNode.getFileExtension());
        assertEquals("getFileLength", 3, fileDataNode.getFileLength());
        assertEquals("getLastModified", fileData.getLastModified(), fileDataNode.getLastModified());
        assertEquals("getDirectory", file.getAbsoluteFile().getParent(), fileDataNode.getDirectory());
        assertEquals("canRead", true, fileDataNode.canRead());
        // assertEquals("getFile", file, fileDataNode.getFile()); Now raises an error
        assertEquals("isPreparedForUpload", false, fileDataNode.isPreparedForUpload());
        assertEquals("getChildCount", 0, fileDataNode.getChildCount());
        assertNull("getChild", fileDataNode.getChild(24));
        assertNull("getChild", fileDataNode.getChild("24"));
        assertEquals("isLeaf", true, fileDataNode.isLeaf());
        assertEquals("parent", null, fileDataNode.getParent());
        assertEquals("model", null, fileDataNode.treeModel);

        assertEquals("FileData link", fileDataNode, fileData.getTreeFileDataNode());
    }

    @Test
    public void testSetGetUploadFlag() {
        assertEquals("getUploadFlag (true)", true, fileDataNode.getUploadFlag());
        fileDataNode.setUploadFlag(false);
        assertEquals("getUploadFlag (false)", false, fileDataNode.getUploadFlag());
    }

    @Test(expected = IllegalStateException.class)
    public void testGetUploadLength_NotPrepared() {
        assertEquals("getUploadLength", 3, fileDataNode.getUploadLength());
    }

    public void testGetUploadLength_Prepared() throws JUploadException {
        fileDataNode.beforeUpload(null);
        assertEquals("getUploadLength", 3, fileDataNode.getUploadLength());
    }

}
