//
// $Id$
//
// jupload - A file upload applet.
//
// Copyright 2010 The JUpload Team
//
// Created: 25 fevr. 2010
// Creator: etienne_sf
// Last modified: $Date$
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
package wjhk.jupload2.filedata;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Vector;

import org.junit.Before;
import org.junit.Test;

import wjhk.jupload2.exception.JUploadException;
import wjhk.jupload2.exception.JUploadIOException;
import wjhk.jupload2.gui.filepanel.FilePanel;
import wjhk.jupload2.gui.filepanel.treeview.FileDataNode;
import wjhk.jupload2.gui.filepanel.treeview.FolderNode;
import wjhk.jupload2.gui.filepanel.treeview.RootNode;
import wjhk.jupload2.policies.UploadPolicy;
import wjhk.jupload2.testhelpers.JUploadContextTestHelper;
import wjhk.jupload2.testhelpers.UploadPolicyTestHelper;
import wjhk.jupload2.upload.AbstractJUploadTestHelper;
import wjhk.jupload2.upload.helper.ByteArrayEncoder;
import wjhk.jupload2.upload.helper.ByteArrayEncoderHTTP;

/**
 * @author etienne_sf
 */
public class DefaultFileDataTest extends AbstractJUploadTestHelper {

    private String rootPathForTestFiles;

    private DefaultFileData fileData;

    private File file;

    private String root;

    /** */
    @Before
    public void setUp() {
        this.rootPathForTestFiles = AbstractJUploadTestHelper.getTestFilesRootPath();
        String filePath = this.rootPathForTestFiles + File.separator + "level1" + File.separator + "ATestFile.txt";
        this.file = new File(filePath);

        assertTrue("The file must exist (" + filePath + ")", this.file.exists());
        assertTrue("The root must exist (" + this.rootPathForTestFiles + ")", new File(rootPathForTestFiles).exists());
        assertTrue("The root must be a valid folder", new File(rootPathForTestFiles).isDirectory());
        assertTrue("The test file must be readable", this.file.canRead());

        this.root = this.file.getParentFile().getAbsolutePath();
        this.fileData = new DefaultFileData(this.file, this.uploadPolicy);
    }

    /** */
    @Test
    public void testConstructor() {
        // Check file attribute and getter
        assertEquals("Check of the file attribute", this.file, this.fileData.file);
        assertEquals("Check of the file getter", this.file, this.fileData.getFile());

        // Check fileSize attribute and getter
        assertEquals("Check of the fileSize attribute", this.file.length(), this.fileData.fileSize);
        assertEquals("Check of the fileSize getter", this.file.length(), this.fileData.getFileLength());

        // Check lastModified attribute and getter
        assertEquals("Check of the lastModified attribute", new Date(this.file.lastModified()),
                this.fileData.fileModified);
        assertEquals("Check of the lastModified getter", new Date(this.file.lastModified()),
                this.fileData.getLastModified());

        // Check mimeType attribute and getter
        assertEquals("Check of the mimeType attribute", JUploadContextTestHelper.TEST_CASE_MIME_TYPE,
                this.fileData.mimeType);
        assertEquals("Check of the mimeType getter", JUploadContextTestHelper.TEST_CASE_MIME_TYPE,
                this.fileData.getMimeType());

        // Check parent attribute and getter
        assertEquals("Check of the parent attribute", this.file.getAbsoluteFile().getParent(), this.fileData.fileDir);
        assertEquals("Check of the parent getter", this.file.getAbsoluteFile().getParent(),
                this.fileData.getDirectory());

        // Check root attribute. Null at construction
        assertNull("Check of the root attribute", this.fileData.fileRoot);

        // Check uploadPolicy attribute
        assertEquals("Check of the uploadPolicy attribute", this.uploadPolicy, fileData.uploadPolicy);

        // Check preparedForUpload attribute
        assertEquals("Check of the preparedForUpload attribute", false, this.fileData.preparedForUpload);
    }

    /** */
    @Test(expected = IllegalArgumentException.class)
    public void testConstructor_KO() {
        new DefaultFileData(new File(this.rootPathForTestFiles), uploadPolicy);
    }

    /**
     * @throws JUploadException
     */
    @Test
    public void testAppendFileProperties() throws JUploadException {
        // /////////////////////////////////////////////////////////////////////////////
        // ////////// A Utility class, to check the properties wich are managed
        // /////////////////////////////////////////////////////////////////////////////
        class ByteArrayEncoderHTTP_CheckAppendTextProperty extends ByteArrayEncoderHTTP {
            String mimeType = null;

            String pathInfo = null;

            String relpathinfo = null;

            String filemodificationdate = null;

            ByteArrayEncoderHTTP_CheckAppendTextProperty() throws JUploadIOException {
                super(DefaultFileDataTest.this.uploadPolicy);
            }

            @Override
            public ByteArrayEncoder appendTextProperty(String name, String value, int index) throws JUploadIOException {
                if (name.equals("mimetype")) {
                    this.mimeType = value;
                } else if (name.equals("pathinfo")) {
                    this.pathInfo = value;
                } else if (name.equals("relpathinfo")) {
                    this.relpathinfo = value;
                } else if (name.equals("filemodificationdate")) {
                    this.filemodificationdate = value;
                } else {
                    throw new java.lang.IllegalArgumentException("Unknown property : " + name);
                }
                return this;
            }
        }
        // /////////////////////////////////////////////////////////////////////////////
        ByteArrayEncoderHTTP_CheckAppendTextProperty bae = new ByteArrayEncoderHTTP_CheckAppendTextProperty();

        int index = 58;
        this.fileData.beforeUpload(this.root);
        this.fileData.appendFileProperties(bae, index);
        assertEquals("Check mimeType value", JUploadContextTestHelper.TEST_CASE_MIME_TYPE, bae.mimeType);
        assertEquals("Check pathInfo value", this.file.getParentFile().getAbsolutePath(), bae.pathInfo);

        // The relpathinfo, is the path relative to the file root.
        assertEquals("The relpathinfo is the part of the file absolute path, wich is after the file root", this.file
                .getParentFile().getAbsolutePath(), this.root /* + File.separator */+ bae.relpathinfo);
        // date here.
        assertNotNull("Check mimeType value", bae.filemodificationdate);
    }

    /**
     * @throws JUploadException
     */
    @Test
    public void testBeforeUpload() throws JUploadException {
        // The next call should not throw an exception.
        this.fileData.beforeUpload(this.root);

        this.fileData.preparedForUpload = false;
        ((UploadPolicyTestHelper) this.uploadPolicy).maxFileSize = 5;
        try {
            // The next call should throw an exception.
            this.fileData.beforeUpload(this.root);
            fail("The file should be too big!");
        } catch (JUploadException e) {
            // Success !
        }
    }

    /** */
    @Test
    public void testGetUploadLength() {
        this.fileData.preparedForUpload = false;
        try {
            this.fileData.getUploadLength();
            fail("getUploadLength should raise an exception when the file is not prepared for upload");
        } catch (IllegalStateException e) {
            // Success!
        }

        this.fileData.preparedForUpload = true;
        assertEquals("Check upload length", this.file.length(), this.fileData.getUploadLength());
    }

    /** */
    @Test
    public void testAfterUpload() {
        this.fileData.preparedForUpload = false;
        try {
            this.fileData.afterUpload();
            fail("getUploadLength should raise an exception when the file is not prepared for upload");
        } catch (IllegalStateException e) {
            // Success!
        }

        this.fileData.preparedForUpload = true;
        this.fileData.afterUpload();
        assertEquals("After afterUpload(), the file is no more prepared", false, this.fileData.preparedForUpload);
    }

    /**
     * @throws JUploadException
     * @throws IOException
     */
    @Test
    public void testGetInputStream() throws JUploadException, IOException {
        this.fileData.preparedForUpload = false;
        try {
            this.fileData.afterUpload();
            fail("getUploadLength should raise an exception when the file is not prepared for upload");
        } catch (IllegalStateException e) {
            // Success!
        }

        this.fileData.preparedForUpload = true;
        InputStream is = this.fileData.getInputStream();
        // Success !
        is.close();
    }

    /** */
    @Test
    public void testGetFileName() {
        assertEquals("Check file name", this.file.getName(), this.fileData.getFileName());
    }

    /** */
    @Test
    public void testGetFileExtension() {
        int lastPoint = this.file.getName().lastIndexOf(".");
        assertTrue("We must have a point, to find the extension!", lastPoint >= 0);
        String extension = this.file.getName().substring(lastPoint + 1);
        assertEquals("Check file extension", extension, DefaultFileData.getExtension(this.file.getName()));
    }

    /** */
    @Test
    public void testCanRead() {
        assertTrue("should be able to read the test file (attribute)", this.fileData.canRead());
        assertTrue("should be able to read the test file (getter)", this.fileData.canRead.booleanValue());

        this.fileData = new DefaultFileData(new File("This is not a file"), this.uploadPolicy);
        assertFalse("should be able to read the test file (attribute)", this.fileData.canRead());
        assertFalse("should be able to read the test file (getter)", this.fileData.canRead.booleanValue());
    }

    /**
     * @throws JUploadException
     */
    @Test
    public void testGetRelativeDir_flatMode() throws JUploadException {
        // Preparation
        this.fileData.fileRoot = "";
        // The relpathinfo, is the path relative to the file root.
        String absPath = (this.file.getParentFile().getAbsolutePath() == null) ? "" : this.file.getParentFile()
                .getAbsolutePath();

        // Go, go, go
        String relativeDir = this.fileData.getRelativeDir();

        // Verification
        assertEquals("Relative Dir (1)", absPath, relativeDir);
        assertEquals("The relpathinfo is the part of the file absolute path, wich is after the file root", absPath,
                this.fileData.fileRoot + relativeDir);

        // ////////////////////////////////////////////////////////////////
        // Let's choose another file root
        int fromIndex = 0;
        for (int i = 0; i < 3; i += 1) {
            int netSlash = absPath.indexOf('/', fromIndex + 1);
            fromIndex = (netSlash >= 0) ? netSlash : absPath.indexOf('\\', fromIndex + 1);
        } // for
        String rootPath = absPath.substring(0, fromIndex);
        this.fileData.beforeUpload(rootPath);

        // Go, go, go
        relativeDir = this.fileData.getRelativeDir();

        // Verification
        assertTrue("The rootPath is a non empty path", rootPath.length() > 5);
        assertEquals("The relpathinfo is the part of the file absolute path, wich is after the file root", absPath,
                this.fileData.fileRoot + relativeDir);

        // ////////////////////////////////////////////////////////////////
        // Let's choose another file root (with a trailing slash)
        String rootPathWithSlash = rootPath + '/';
        this.fileData.beforeUpload(rootPathWithSlash);

        // Go, go, go
        relativeDir = this.fileData.getRelativeDir();

        // Verification
        assertTrue("The rootPath is a non empty path", rootPathWithSlash.length() > 5);
        assertEquals("The relpathinfo is the part of the file absolute path, wich is after the file root", absPath,
                this.fileData.fileRoot + relativeDir);

        // ////////////////////////////////////////////////////////////////
        // Let's choose another file root (with a trailing anti-slash)
        String rootPathWithAntiSlash = rootPath + '\\';
        this.fileData.beforeUpload(rootPathWithAntiSlash);

        // Go, go, go
        relativeDir = this.fileData.getRelativeDir();

        // Verification
        assertTrue("The rootPath is a non empty path", rootPathWithAntiSlash.length() > 5);
        assertEquals("The relpathinfo is the part of the file absolute path, wich is after the file root", absPath,
                this.fileData.fileRoot + relativeDir);
    }

    /**
     * @throws JUploadException
     */
    @Test
    public void testGetRelativeDir_independentTreeViewMode() throws JUploadException {
        // Preparation
        // We go to INDEPENDENT_TREE_VIEW
        String oldValue = System.getProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE);
        System.setProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE,
                FilePanel.FileListViewMode.INDEPENDENT_TREE_VIEW.toString());

        try {
            // Preparation
            this.fileData.fileRoot = "";
            // We need to create a path, to check that every thing is ok.
            RootNode rootNode = (RootNode) this.fileDataTreeViewModel.getAbsoluteRoot();
            FolderNode folder = (FolderNode) rootNode.addChild(new FolderNode(getTestFile("files"), this.uploadPolicy,
                    null, null));
            FolderNode subfolder = (FolderNode) folder.addChild(new FolderNode(getTestFile("files/level1"),
                    this.uploadPolicy, null, null));
            FileDataNode fileDataNode = (FileDataNode) subfolder.addChild(this.fileData);
            assertEquals("fileDataNode", fileDataNode, this.fileData.treeFileDataNode);

            // go, go, go
            String relativeDir = this.fileData.getRelativeDir();

            // Verification
            assertEquals("Relative Dir (1)", "files/level1", relativeDir);
        } finally {
            // Cleaning of the test environment
            if (oldValue == null) {
                System.clearProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE);
            } else {
                System.setProperty(UploadPolicy.PROP_FILE_LIST_VIEW_MODE, oldValue);
            }
        }
    }

    /** */
    @Test
    public void getPreparedForUpload() {
        this.fileData.preparedForUpload = true;
        assertTrue("File is prepared", this.fileData.isPreparedForUpload());
        this.fileData.preparedForUpload = false;
        assertFalse("File is not prepared", this.fileData.isPreparedForUpload());
    }

    /** */
    @Test
    public void testGetRoot() {
        Vector<DefaultFileData> fileArray = new Vector<DefaultFileData>(5);

        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level3/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level33/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level3/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level33/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level3/file.txt"),
                uploadPolicy));
        String result = DefaultFileData.getRoot(fileArray).getAbsolutePath();
        String expected = this.rootPathForTestFiles + "level1" + File.separator + "level2";
        assertTrue("Check getRoot: checking '" + result + "' against '" + expected + "'", result.endsWith(expected));

        fileArray.clear();
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level3/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level33/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level22/level3/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level33/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level33/file.txt"),
                uploadPolicy));
        result = DefaultFileData.getRoot(fileArray).getAbsolutePath();
        expected = this.rootPathForTestFiles + "level1";
        assertTrue("Check getRoot: checking '" + result + "' against '" + expected + "'", result.endsWith(expected));

        fileArray.clear();
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level11/level2/level3/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level33/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level3/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1/level2/level3/file.txt"),
                uploadPolicy));
        fileArray.add(new DefaultFileData(new File(this.rootPathForTestFiles + "level1.txt"), uploadPolicy));
        result = DefaultFileData.getRoot(fileArray).getAbsolutePath() + File.separator;
        expected = this.rootPathForTestFiles /* + File.separator */;
        assertTrue("Check getRoot: checking '" + result + "' against '" + expected + "'", result.endsWith(expected));

    }

}