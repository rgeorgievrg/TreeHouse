//
// $Id$
//
// jupload - A file upload applet.
//
// Copyright 2015 The JUpload Team
//
// Created: 3 févr. 2015
// Creator: etienne_sf
// Last modified: $Date$
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

package wjhk.jupload2.upload;

import static org.junit.Assert.*;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.junit.Before;
import org.junit.Test;

import wjhk.jupload2.testhelpers.FileDataTestHelper;
import wjhk.jupload2.testhelpers.FilePanelTestHelper;

/**
 * @author etienne_sf
 */
public class FilePreparationThreadTest extends AbstractJUploadTestHelper {

    /** The number of files to put in the file list */
    public final static int NB_FILES_TO_UPLOAD = 5;

    /** The if of the file, which will have the uploadFlag set to false */
    public final static int NUM_FILE_WITH_UPLOADFLAG_TO_FALSE = 3;

    /** The instance to be tested */
    // public FilePreparationThread filePreparationThread = null;

    /* The mock objects, to allow testing */
    BlockingQueue<UploadFileData> preparedFileQueue;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        // Let's create our own set of files to upload, for this test case.
        setupFileList(NB_FILES_TO_UPLOAD);

        preparedFileQueue = new ArrayBlockingQueue<UploadFileData>(20);

        // The FilePanel.removeFileNotToUpload() must be called once, during FilePreparationThread construction
        assertEquals("FilePanel.removeFileNotToUpload() not called before constructor", 0,
                ((FilePanelTestHelper) this.filePanel).removeFileNotToUpload_NbCalls);
        filePreparationThread = new FilePreparationThread(preparedFileQueue, fileUploadManagerThread, uploadPolicy);
        assertEquals("FilePanel.removeFileNotToUpload() called once during constructor", 1,
                ((FilePanelTestHelper) this.filePanel).removeFileNotToUpload_NbCalls);
    }

    /**
     * Test method for {@link wjhk.jupload2.upload.FilePreparationThread#run()}.
     * 
     * @throws InterruptedException
     */
    @Test
    public void testRun() throws InterruptedException {
        // Checks, before run
        assertEquals("getNbTotalNumberOfPreparedBytes", 0, filePreparationThread.getNbTotalNumberOfPreparedBytes(), 0);
        assertEquals("getTotalFileBytesToSend", 0, filePreparationThread.getTotalFileBytesToSend(), 0);
        assertEquals("nbFilesToSend", NB_FILES_TO_UPLOAD, filePreparationThread.getNbFilesToSend());
        assertEquals("getNbPreparedFiles", 0, filePreparationThread.getNbPreparedFiles());

        // go, go, go
        filePreparationThread.run();

        // Checks, after run
        assertEquals("nbFilesToSend", NB_FILES_TO_UPLOAD, filePreparationThread.getNbFilesToSend());
        assertEquals("getNbPreparedFiles", NB_FILES_TO_UPLOAD, filePreparationThread.getNbPreparedFiles());
        assertEquals("getNbTotalNumberOfPreparedBytes",
                (NB_FILES_TO_UPLOAD) * (FileDataTestHelper.FILE_CONTENT_PREFIX.length() + 1),
                filePreparationThread.getNbTotalNumberOfPreparedBytes(), 0);
        assertEquals("getTotalFileBytesToSend", (NB_FILES_TO_UPLOAD)
                * (FileDataTestHelper.FILE_CONTENT_PREFIX.length() + 1),
                filePreparationThread.getTotalFileBytesToSend(), 0);
        // Checks the file names
        for (int i = 0; i < NB_FILES_TO_UPLOAD; i += 1) {
            assertEquals("File name " + i, i + ".txt", preparedFileQueue.take().getFileName());
        }
    }
}
